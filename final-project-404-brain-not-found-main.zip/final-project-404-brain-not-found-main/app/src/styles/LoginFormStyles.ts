import { SxProps, Theme } from '@mui/system';

const loginFormStyles: { [key: string]: SxProps<Theme> } = {
  container: {
    display: 'flex',
    justifyContent: 'center', // Centers horizontally
    alignItems: 'center', // Centers vertically
    minHeight: '100vh', // Ensures the container takes full viewport height
  },
  paper: {
    padding: 3,
    backgroundColor: 'background.paper',
    width: '100%',
    maxWidth: '400px', // Sets a maximum width for the dialog
    boxSizing: 'border-box', // Ensures padding is included in the element's total width
    borderRadius: 2, // Optional: gives the dialog rounded corners
    boxShadow: 3, // Optional: adds a shadow to make it stand out
  },
  logo: {
    display: 'flex',
    justifyContent: 'center',
    marginBottom: 2,
  },
  logoImage: {
    maxWidth: '200px',
    height: 'auto',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  formTitle: {
    marginBottom: 2,
    color: 'text.primary',
  },
  textField: {
    backgroundColor: 'background.default',
    marginBottom: 2,
  },
  button: {
    marginTop: 2,
  },
  alert: {
    marginBottom: 2,
  },
  registerLink: {
    textDecoration: 'none',
    color: 'primary.main',
  },
  authLink: {
    textDecoration: 'none',
    color: 'primary.main',
    marginTop: 2,
  },
};

export default loginFormStyles;
