import { SxProps, Theme } from '@mui/system';

// Define the styles for the Homepage component
export const containerStyle: SxProps<Theme> = {
  padding: '2rem',
  overflow: 'auto',
  backgroundColor: '#f5f5f5',
};

export const searchBarContainerStyle: SxProps<Theme> = {
  display: 'flex',
  alignItems: 'center',
  marginBottom: '1rem',
};

export const searchFieldStyle: SxProps<Theme> = {
  flex: 1,
  marginRight: '1rem',
};

export const sortDropdownStyle: SxProps<Theme> = {
  minWidth: 200,
};

export const cardStyle: SxProps<Theme> = {
  display: 'flex',
  marginBottom: '2rem',
  width: '90vw',
  boxShadow: '0 2px 5px rgba(0,0,0,0.1)',
  backgroundColor: '#fff',
};

export const cardMediaStyle: SxProps<Theme> = {
  width: 151,
  padding: 2,
};

export const cardContentStyle: SxProps<Theme> = {
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  gap: '1rem',
  padding: '1rem',
};

export const cardTitleStyle: SxProps<Theme> = {
  marginTop: '1rem',
  marginLeft: '1rem',
  color: '#333',
};

export const cardTextStyle: SxProps<Theme> = {
  color: 'text.secondary',
};

export const buttonContainerStyle: SxProps<Theme> = {
  margin: '1rem',
  display: 'flex',
  justifyContent: 'center',
};

export const paginationContainerStyle: SxProps<Theme> = {
  display: 'flex',
  justifyContent: 'center',
  marginTop: '2rem',
};
