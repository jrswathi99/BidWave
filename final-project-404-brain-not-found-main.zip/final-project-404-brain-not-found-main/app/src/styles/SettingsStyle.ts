export const styles = {
    container: {
      padding: '16px',
      maxWidth: '600px',
      margin: '0 auto',
      marginTop:'20px',
      backgroundColor: '#f5f5f5',
      borderRadius: '8px',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    },
    title: {
      fontSize: '1.5rem',
      fontWeight: '600',
      marginBottom: '16px',
    },
    section: {
      marginTop: '16px',
    },
    sectionTitle: {
      fontSize: '1rem',
      fontWeight: '500',
      marginBottom: '8px',
    },
    select: {
      marginTop: '8px',
    },
    button: {
      marginTop: '24px',
      width: '100%',
    },
  };
  