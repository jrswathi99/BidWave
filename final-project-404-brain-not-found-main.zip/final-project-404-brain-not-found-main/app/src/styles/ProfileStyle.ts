// src/styles/profileStyles.ts

import { SxProps, Theme } from '@mui/system';

export const profileContainer: SxProps<Theme> = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  minHeight: '100vh',
  backgroundColor: '#f5f5f5',
  padding: '2rem',
};

export const profileImage: SxProps<Theme> = {
  width: '120px',
  height: '120px',
  borderRadius: '50%',
  marginBottom: '20px',
  border: '3px solid #3f51b5',
};

export const formContainer: SxProps<Theme> = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  width: '100%',
  maxWidth: '500px',
  backgroundColor: 'white',
  padding: '2rem',
  borderRadius: '8px',
  boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
};

export const heading: SxProps<Theme> = {
  fontWeight: 'bold',
  marginBottom: '20px',
  fontSize: '2rem',
};

export const inputFields: SxProps<Theme> = {
  marginBottom: '20px',
  width: '100%', // Ensure all fields have the same width
};

export const button: SxProps<Theme> = {
  width: '100%',
  color: 'white',
};
