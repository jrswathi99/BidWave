import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { jwtDecode } from 'jwt-decode';
import { Box, Typography, TextField, Button, CircularProgress, Alert, CardMedia } from '@mui/material';
import { fetchProductByID } from '../services/product-service';
import { Product } from '../models/Products';
import { getAuctionById, patchAuction } from '../services/auction-service';
import { Auction } from '../models/Auction';
import { createBid, getBidsById, getBidsByProductId, updateBid } from '../services/bid-service';
import { Bid } from '../models/Bid';
import { useTranslation } from 'react-i18next';

const BiddingPage: React.FC = () => {
  const { t } = useTranslation();
  const { auctionId, productId } = useParams<{ auctionId: string; productId: string }>(); // Product ID from URL
  const [userId, setUserId] = useState<string | null>(null); // State to store userId
  const [product, setProduct] = useState<Product | null>(null);
  const [token, setToken] = useState<String | null>(null);
  const [auction, setAuction] = useState<Auction | null>(null);
  const [amount, setAmount] = useState(''); // State to store the user's bid amount
  const [existingBid, setExistingBid] = useState<number | null>(null);
  const [existingBidId, setExistingBidId] = useState<string | null | undefined>(null);
  const [highestBid, setHighestBid] = useState<number | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [timeRemaining, setTimeRemaining] = useState<string>('');

  function getUserBid(bids: Bid[], userId: string): { amount: number | null; bidId: string | null | undefined } {
    const userBid = bids.find((bid) => bid.userId === userId);
    return {
      amount: userBid ? userBid.amount : null,
      bidId: userBid ? userBid._id : null,
    };
  }

  // Decode the userId from the token stored in localStorage
  useEffect(() => {
    let token = localStorage.getItem('jwtToken'); // Get the token from localStorage
    setToken(token);
    if (token) {
      try {
        const decodedToken: { id: string } = jwtDecode(token); // Decode the token
        console.log('Decoded Token:', decodedToken); // Debug: Log the decoded token
        setUserId(decodedToken.id); // Use `id` from the decoded token
      } catch (err) {
        console.error('Error decoding token:', err);
        setError(t('failedToAuthenticateUser'));
      }
    } else {
      console.warn('No token found in localStorage.');
      setError(t('userNotAuthenticated'));
    }
  }, []);

  useEffect(() => {
    const fetchProductDetails = async () => {
      try {
        setLoading(true);

        // Fetch product details (only once)
        const productResponse = await fetchProductByID(productId || '');
        setProduct(productResponse || null);

        // Fetch auction details for the first time
        const auction = await getAuctionById(auctionId || '');
        setAuction(auction);

        // Fetch initial highest bid
        let highestBid = null;
        if (auction.highestBidId) {
          highestBid = await getBidsById(auction.highestBidId || '');
        }
        if (highestBid) {
          setHighestBid(highestBid.amount);
        }

        let token = localStorage.getItem('jwtToken');
        const decodedToken: { id: string } = jwtDecode(token || '');

        // Fetch user's existing bid for this product (if any)
        const bidResponse = await getBidsByProductId(productId || '');
        const userBid = getUserBid(bidResponse, decodedToken.id || '');
        setExistingBid(userBid.amount);
        setExistingBidId(userBid.bidId);

        // Start timer to calculate remaining time
        if (auction.endTime) {
          const endTime = new Date(auction.endTime);
          startCountdownTimer(endTime);
        }
      } catch (err: any) {
        setError(err.message || t('anErrorOccurred'));
      } finally {
        setLoading(false);
      }
    };

    const fetchAuctionUpdates = async () => {
      try {
        // Fetch auction details to get updated highest bid
        const auction = await getAuctionById(auctionId || '');
        setAuction(auction);

        // Fetch the latest highest bid
        let highestBid = null;
        if (auction.highestBidId) {
          highestBid = await getBidsById(auction.highestBidId || '');
        }
        if (highestBid) {
          setHighestBid(highestBid.amount);
        }
      } catch (err: any) {
        setError(err.message || 'An error occurred.');
      }
    };

    // Fetch product details once
    fetchProductDetails();

    // Set up interval to poll auction updates
    const intervalId = setInterval(() => {
      fetchAuctionUpdates();
    }, 5000);

    return () => {
      clearInterval(intervalId); // Cleanup on component unmount
    };
  }, [productId, auctionId]);

  // Countdown timer logic
  const startCountdownTimer = (endTime: Date) => {
    const interval = setInterval(() => {
      const now = new Date();
      const timeDiff = endTime.getTime() - now.getTime();

      if (timeDiff <= 0) {
        clearInterval(interval); // Stop the timer when the auction ends
        setTimeRemaining(t('auctionHasEnded'));
        const updatedAuction: Partial<Auction> = {
          status: 'closed' as 'closed',  // Ensure the status matches the allowed type
        };

        patchAuction(auction?._id || '', updatedAuction)
      } else {
        const days = Math.floor(timeDiff / (1000 * 60 * 60 * 24)); // Calculate days
        const hours = Math.floor((timeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)); // Calculate hours
        const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60)); // Calculate minutes
        const seconds = Math.floor((timeDiff % (1000 * 60)) / 1000); // Calculate seconds

        setTimeRemaining(`${days}d ${hours}h ${minutes}m ${seconds}s`); // Display days, hours, minutes, seconds
      }
    }, 1000);
  };

  const handleBidSubmit = async () => {
    if (!userId) {
      alert(t('userNotAuthenticated'));
      return;
    }

    // Convert the amount to a number
    const bidAmount = parseFloat(amount);

     if (bidAmount < product?.minprice) {
        // Show a message if the bid is less than the minimum price
        alert(t('yourBidMustBeHigherThanTheMinimumPrice'));
        return;
      } else if(bidAmount < highestBid) {
        // Show a message if the bid is less than the current highest bid
        alert(t('yourBidMustBeHigherThanTheCurrentHighestBid'));
        return;
    }
    try {
      let bidResponse;

      if (existingBid) {
        // Update existing bid
        bidResponse = await updateBid(existingBidId || '', amount);
      } else {
        // Create new bid
        bidResponse = await createBid(productId || '', userId, amount);
      }

      if (!bidResponse) {
        throw new Error(t('failedToSubmitBid'));
      }

      const updatedAuction = {
        highestBidId: bidResponse._id,
      };

      patchAuction(auction?._id || '', updatedAuction);

      alert(t('bidSubmittedSuccessfully'));
      setExistingBid(bidAmount); // Update the existing bid with the new amount
    } catch (err: any) {
      alert(err.message || t('anErrorOccurred'));
    }
  };

  const copyToClipboard = () => {
    const productInfo = `
      Product: ${product.itemName}
      Description: ${product.description}
      Category: ${product.category}
      Base Price: $${product.minprice}
      Highest Bid: ${highestBid ? `$${highestBid}` : 'No bids yet'}
      Your Current Bid: ${existingBid ? `$${existingBid}` : 'No bids yet'}
    `;

    navigator.clipboard.writeText(productInfo).then(
      () => alert('Product and bid information copied to clipboard!'),
      (err) => alert('Failed to copy product info: ', err)
    );
  };


  if (loading) {
    return (
      <Box sx={{ padding: '2rem', textAlign: 'center' }}>
        <CircularProgress />
        <Typography variant="body1" sx={{ marginTop: '1rem' }}>
          {t('loadingProductDetails')}
        </Typography>
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ padding: '2rem' }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }
  return (
    <Box sx={{ padding: '2rem' }}>
      {product && (
        <>
          {timeRemaining === 'Auction has ended' && highestBid != null && (
            <>
              {existingBid === highestBid && (
                <Alert severity="success" sx={{ marginBottom: '1rem' }}>
                  {t('youHaveWonTheBid')}
                </Alert>
              )}
              {existingBid !== highestBid && existingBid != null && highestBid != null && existingBid < highestBid && (
                <Alert severity="error" sx={{ marginBottom: '1rem' }}>
                  {t('youHaveLostTheBid')}
                </Alert>
              )}
            </>
          )}

          {timeRemaining != t('auctionHasEnded') && (
            <>
              {/* Existing Conditions for Bids */}
              {existingBid === highestBid && highestBid != null && (
                <Alert severity="success" sx={{ marginBottom: '1rem' }}>
                  {t('youAreWinningTheBid')} {/* Use translation key */}
                </Alert>
              )}

              {existingBid !== null && existingBid !== highestBid && highestBid != null && existingBid < highestBid && (
                <Alert severity="error" sx={{ marginBottom: '1rem' }}>
                  {t('youAreLosingTheBid')} {/* Use translation key */}
                </Alert>
              )}

              {existingBid == null && (
                <Alert severity="warning" sx={{ marginBottom: '1rem' }}>
                  {t('bidNotPlacedYet')} {/* Use translation key */}
                </Alert>
              )}
            </>
          )}

          <Typography variant="h4">{product.itemName}</Typography>

          <Box sx={{ display: 'flex', gap: '5rem' }}>
            <CardMedia
              component="img"
              sx={{ width: 200, padding: 2 }}
              image={product.images?.[0] || 'app/src/assets/react.svg'}
              alt={product.itemName}
            />
            <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', flex: 1 }}>
              <Typography variant="body1">{t('description')}: {product.description}</Typography> {/* Use translation key */}
              <Typography variant="body1">{t('category')}: {product.category}</Typography> {/* Use translation key */}
              <Typography variant="body1">{t('basePrice')}: $ {product.minprice}</Typography> {/* Use translation key */}
              <Typography variant="body1">
                {t('highestBid')}: {highestBid ? `$${highestBid}` : t('noBidsYet')} {/* Use translation key */}
              </Typography>
              <Typography variant="body1">
                {t('yourCurrentBid')}: {existingBid ? `$${existingBid}` : t('noBidsYet')} {/* Use translation key */}
              </Typography>
              <Typography variant="body1">{t('timeRemaining')}: {timeRemaining}</Typography> {/* Use translation key */}
            </Box>
          </Box>

          <Box sx={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginTop: '1rem' }}>
            <TextField
              label={t('yourBid')} // Use translation key
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              sx={{ width: '100%' }}
              disabled={timeRemaining === t('auctionHasEnded')} // Use translation key
            />
            <Button
              variant="contained"
              color="primary"
              onClick={handleBidSubmit}
              sx={{ width: '100%' }}
              disabled={timeRemaining === t('auctionHasEnded')} // Use translation key
            >
              {existingBid ? t('updateBid') : t('placeBid')} {/* Use translation key */}
            </Button>
            <Button variant="outlined" onClick={copyToClipboard}>
              Copy Bid to Clipboard
            </Button>
          </Box>
        </>
      )}
    </Box>
  );

};

export default BiddingPage;
