import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  registrationSuccess: false, // Track if the user registration is successful
};

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    setRegistrationSuccess: (state, action) => {
      state.registrationSuccess = action.payload; // Set success status
    },
  },
});

export const { setRegistrationSuccess } = userSlice.actions;
export default userSlice.reducer;
