import React, { useState } from 'react';
import { AppBar, Toolbar, Typography, Box } from '@mui/material';
import AdminNavbarLinks from './AdminNavbarLink';
import NavbarProfileMenu from './NavbarProfileMenu';

const Navbar: React.FC<{ onLogout: () => void }> = ({ onLogout }) => {

  const handlePage = (page: string) => {
    console.log(`Switching to page: ${page}`);
  };
  return (
    <>
      <AppBar position="sticky">
        <Toolbar>
          {/* Logo */}
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            BidWave
          </Typography>

          {/* Links */}
          <Box sx={{ flexGrow: 1, display: 'flex', justifyContent: 'space-evenly' }}>
            <AdminNavbarLinks  onPageSwitch= { handlePage} />
          </Box>

          {/* Profile Menu */}
          <NavbarProfileMenu onLogout={onLogout} />
        </Toolbar>
      </AppBar>
    </>
  );
};

export default Navbar;
