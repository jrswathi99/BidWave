import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Box, Button, MenuItem, Select, Typography, SelectChangeEvent } from '@mui/material';
import { styles } from '../styles/SettingsStyle.ts'; // Import the styles

const Settings: React.FC = () => {
  const { i18n, t } = useTranslation();
  const [selectedLanguage, setSelectedLanguage] = useState(i18n.language);

  const handleChangeLanguage = (event: SelectChangeEvent<string>) => {
    const language = event.target.value as string;
    setSelectedLanguage(language);
  };

  const handleSubmit = () => {
    i18n.changeLanguage(selectedLanguage);
    // Add any additional actions you want to perform on submit
  };

  return (
    <Box sx={styles.container}>
      <Typography variant="h6" sx={styles.title}>
        {t('settings')}
      </Typography>

      <Box sx={styles.section}>
        <Typography variant="body1" sx={styles.sectionTitle}>
          {t('changeLanguage')}
        </Typography>
        <Select
          value={selectedLanguage}
          onChange={handleChangeLanguage}
          displayEmpty
          fullWidth
          sx={styles.select}
        >
          <MenuItem value="en">English</MenuItem>
          <MenuItem value="fr">Français</MenuItem>
          <MenuItem value="de">German</MenuItem>
          <MenuItem value="zh">Chinese</MenuItem>
          {/* Add more languages as needed */}
        </Select>
      </Box>

      <Button variant="contained" onClick={handleSubmit} sx={styles.button}>
        {t('submit')}
      </Button>
    </Box>
  );
};

export default Settings;
