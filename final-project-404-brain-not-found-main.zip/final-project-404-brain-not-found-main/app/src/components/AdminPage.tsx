import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import CardMedia from "@mui/material/CardMedia";
import { Alert } from "@mui/material";
import { fetchUsers, deleteUser } from "../services/adminpage-services.ts";
import { fetchProducts } from "../services/adminpage-services.ts";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next"; // Import useTranslation

interface User {
  _id: string;
  username: string;
  email: string;
  gender: string;
  age: number;
}

interface Product {
  _id: string;
  itemName: string;
  category: string;
  description: string;
  images?: string[];
  minprice: number;
  userId: string;
}

const AdminPage: React.FC = () => {
  const { t } = useTranslation(); // Translation hook
  const [users, setUsers] = useState<User[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const navigate = useNavigate();

  useEffect(() => {
    const fetchAllData = async () => {
      try {
        // Fetch users
        const fetchedUsers = await fetchUsers("admin404@gmail.com", "admin@404");
        setUsers(fetchedUsers.data || fetchedUsers);

        // Fetch products
        const fetchedProducts = await fetchProducts("admin404@gmail.com", "admin@404");
        setProducts(fetchedProducts);
      } catch (error: any) {
        setError(error.message || t("errorFetchingUsers")); // Use translation key
      }
    };

    fetchAllData();
  }, [t]);

  const handleDeleteUser = async (userId: string) => {
    try {
      await deleteUser(userId, "admin404@gmail.com", "admin@404");
      setUsers(users.filter((user) => user._id !== userId));
      setSuccessMessage(t("userDeletedSuccessfully")); // Use translation key
    } catch (error: any) {
      setError(error.message || t("errorDeletingUser")); // Use translation key
    }
  };

  const getUserById = (userId: string): User | undefined => {
    return users.find((user) => user._id === userId);
  };

  return (
    <Box sx={{ padding: "2rem", overflow: "auto" }}>
      {error && <Alert severity="error">{error}</Alert>}
      {successMessage && <Alert severity="success">{successMessage}</Alert>}

      <Typography variant="h4" gutterBottom>Users</Typography>
      {users.map((user) => (
        <Card key={user._id} sx={{ marginBottom: "1rem", padding: "1rem" }}>
          <CardContent>
            <Typography variant="h6">{t("name")}: {user.username}</Typography> {/* Use translation key */}
            <Typography variant="body1">{t("email")}: {user.email}</Typography> {/* Use translation key */}
            <Typography variant="body1">{t("gender")}: {user.gender}</Typography> {/* Use translation key */}
            <Typography variant="body1">{t("age")}: {user.age}</Typography> {/* Use translation key */}
          </CardContent>
          <Box sx={{ display: "flex", justifyContent: "flex-end", padding: "0 1rem 1rem" }}>
            <Button variant="contained" color="secondary" onClick={() => handleDeleteUser(user._id)}>
              {t("deleteUser")} {/* Use translation key */}
            </Button>
          </Box>
        </Card>
      ))}

      <Typography variant="h4" gutterBottom>Products</Typography>
      {products.map((product) => {
        const user = getUserById(product.userId);
        return (
          <Card key={product._id} sx={{ marginBottom: "1rem", padding: "1rem" }}>
            <CardMedia
              component="img"
              image={product.images?.[0] || "placeholder.jpg"}
              alt={product.itemName}
              sx={{ width: "100%", height: "200px" }}
            />
            <CardContent>
              <Typography variant="h6">{product.itemName}</Typography>
              <Typography>Category: {product.category}</Typography>
              <Typography>Description: {product.description}</Typography>
              <Typography>Base Price: ${product.minprice}</Typography>
              {user && (
                <>
                  <Typography>Added By: {user.username}</Typography>
                  <Typography>User Email: {user.email}</Typography>
                </>
              )}
            </CardContent>
          </Card>
        );
      })}
    </Box>
  );
};

export default AdminPage;