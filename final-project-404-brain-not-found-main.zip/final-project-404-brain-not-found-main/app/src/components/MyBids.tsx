import React, { useEffect, useState } from 'react';
import { Box, Typography, CardMedia, Button, Alert, Card, TextField, Pagination, Select, MenuItem, FormControl, InputLabel } from '@mui/material';
import { jwtDecode } from 'jwt-decode';
import { getBidsById, getBidsByUserId } from '../services/bid-service';
import { fetchProductByID } from '../services/product-service';
import { getAuctionByProductId } from '../services/auction-service';
import { Auction } from '../models/Auction';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next'; // Import useTranslation

const UserBidsPage = () => {
    const { t } = useTranslation(); // Translation hook
  const [bids, setBids] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [auctions, setAuctions] = useState<Auction[]>([]);
  const [highestBids, setHighestBids] = useState<Record<number, number | null>>({});
  const [timeLeftMap, setTimeLeftMap] = useState<Record<number, string>>({});
  const [searchQuery, setSearchQuery] = useState<string>(''); // Search query state
  const [sortCriteria, setSortCriteria] = useState<string>(''); // Sort criteria
  const [currentPage, setCurrentPage] = useState<number>(1); // Pagination state
  const itemsPerPage = 5; // Number of items per page

  let token = localStorage.getItem('jwtToken');
  const decoded: { id: string } = jwtDecode(token || '');
  const userId = decoded.id;
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBids = async () => {
      try {
        const response = await getBidsByUserId(userId);
        const userBids = response;

        const productIds = userBids.map((bid: any) => bid.productId);

        const productsData = await Promise.all(
          productIds.map(async (productId: string) => {
            const productResponse = await fetchProductByID(productId);
            const auctionResponse = await getAuctionByProductId(productResponse._id || '');
            return {
              product: productResponse,
              auction: auctionResponse,
              bid: userBids.find((bid: any) => bid.productId === productId),
            };
          })
        );

        setProducts(productsData);
        setAuctions(productsData.flatMap((data) => data.auction));
      } catch (error) {
        console.error('Error fetching bids or products:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchBids();
  }, [userId]);

  useEffect(() => {
    const calculateTimeLeft = (auction: Auction) => {
      const now = new Date();
      const endTime = new Date(auction.endTime);
      const difference = endTime.getTime() - now.getTime();

            if (difference <= 0) {
                return t('auctionEnded'); // Use translation key
            }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      return `${days}d ${hours}h ${minutes}m ${seconds}s`;
    };

    const intervalId = setInterval(() => {
      const updatedTimeLeft = { ...timeLeftMap };

      products.forEach((product) => {
        product?.auction?.forEach((auction) => {
          updatedTimeLeft[auction._id] = calculateTimeLeft(auction);
        });
      });

      setTimeLeftMap(updatedTimeLeft);
    }, 1000);

    return () => clearInterval(intervalId);
  }, [auctions, products, timeLeftMap, t]);

  // Filter products based on the search query
  const filteredProducts = products.filter((productData) =>
    productData.product.itemName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortCriteria) {
      case 'itemName':
        return a.product.itemName.localeCompare(b.product.itemName);
      case 'minprice':
        return a.product.minprice - b.product.minprice;
      default:
        return 0;
    }
  });

  // Pagination logic
  const totalPages = Math.ceil(sortedProducts.length / itemsPerPage);
  const paginatedProducts = sortedProducts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handlePageChange = (event: React.ChangeEvent<unknown>, value: number) => {
    setCurrentPage(value);
  };

  if (loading) {
    return <Typography variant="h6">{t('loading')}</Typography>; // Use translation key
  }

  return (
    <Box sx={{ padding: '2rem' }}>
      {/* Search Bar and Sort Dropdown */}
      <Box sx={{ display: 'flex', alignItems: 'center', marginBottom: '1rem' }}>
        <TextField
          placeholder={t('searchYourBids')} // Use translation key
          variant="outlined"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          sx={{ flex: 1, marginRight: '1rem' }}
        />
        <FormControl variant="outlined" size="small" sx={{ minWidth: 200 }}>
          <InputLabel>{t('sortBy')}</InputLabel> {/* Use translation key */}
          <Select
            value={sortCriteria}
            onChange={(e) => setSortCriteria(e.target.value)}
            label={t('sortBy')} // Use translation key
          >
            <MenuItem value="">{t('none')}</MenuItem> {/* Use translation key */}
            <MenuItem value="itemName">{t('itemName')}</MenuItem> {/* Use translation key */}
            <MenuItem value="minprice">{t('price')}</MenuItem> {/* Use translation key */}
          </Select>
        </FormControl>
      </Box>

      {paginatedProducts.length === 0 ? (
        <Alert severity="info">{t('noBidsPlaced')}</Alert> // Use translation key
      ) : (
        paginatedProducts.map((productData, index) => {
          const auction = productData.auction.find(
            (auc) => auc.productId === productData.product._id
          );
          const timeLeft = auction ? timeLeftMap[auction._id] : t('loadingTimeLeft'); // Use translation key
          const highestBid = highestBids[auction?._id] ?? t('noBidsYet'); // Use translation key

          return (
            <Card
              key={index}
              sx={{
                display: 'flex',
                flexDirection: 'column',
                marginBottom: '2rem',
                padding: '1rem',
                boxShadow: '0 2px 5px rgba(0,0,0,0.1)',
              }}
              onClick={() => navigate(`/products/${auction._id}/${productData.product._id}`)}
            >
              <Typography variant="h5" sx={{ marginBottom: '1rem' }}>
                {productData.product.itemName}
              </Typography>
              <Box sx={{ display: 'flex', gap: '1rem', marginBottom: '1rem' }}>
                <CardMedia
                  component="img"
                  sx={{ width: 200, padding: 2 }}
                  image={productData.product.images?.[0] || 'https://via.placeholder.com/150'}
                  alt={productData.product.itemName}
                />
                <Box
                  sx={{
                    display: 'grid',
                    gridTemplateColumns: '1fr 1fr',
                    gap: '1rem',
                    flex: 1,
                  }}
                >
                  <Typography variant="body1">{t('description')}: {productData.product.description}</Typography> {/* Use translation key */}
                  <Typography variant="body1">{t('category')}: {productData.product.category}</Typography> {/* Use translation key */}
                  <Typography variant="body1">{t('basePrice')}: $ {productData.product.minprice}</Typography> {/* Use translation key */}
                  <Typography variant="body1">
                    {t('highestBid')}: {typeof highestBid === 'number' ? `$${highestBid}` : highestBid} {/* Use translation key */}
                  </Typography>
                  <Typography variant="body1">
                    {t('yourCurrentBid')}: {productData.bid ? `$${productData.bid.amount}` : t('noBidsYet')} {/* Use translation key */}
                  </Typography>
                  <Typography variant="body1">{t('timeRemaining')}: {timeLeft}</Typography> {/* Use translation key */}
                </Box>
              </Box>
            </Card>
          );
        })
      )}

      {/* Pagination */}
      <Box sx={{ display: 'flex', justifyContent: 'center', marginTop: '2rem' }}>
        <Pagination
          count={totalPages}
          page={currentPage}
          onChange={handlePageChange}
          color="primary"
        />
      </Box>
    </Box>
  );
};

export default UserBidsPage;