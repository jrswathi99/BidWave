import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  Pagination,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from '@mui/material';
import { fetchProducts, fetchAuctions } from '../services/homepage-service';
import { Auction } from '../models/Auction';
import { getBidsById } from '../services/bid-service';
import { Product } from '../models/Products';
import { jwtDecode } from 'jwt-decode';
import { patchAuction } from '../services/auction-service';
import { useTranslation } from 'react-i18next';

const Homepage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [auctions, setAuctions] = useState<Auction[]>([]);
  const [highestBids, setHighestBids] = useState<Record<string, number>>({});
  const [timeLeftMap, setTimeLeftMap] = useState<Record<string, string>>({});
  const [searchQuery, setSearchQuery] = useState<string>(''); // Search query
  const [sortCriteria, setSortCriteria] = useState<string>(''); // Sort criteria
  const [currentPage, setCurrentPage] = useState<number>(1); // Pagination
  const itemsPerPage = 5; // Items per page

  let token = localStorage.getItem('jwtToken');
  const decoded: { id: string } = jwtDecode(token || '');
  const userId = decoded.id;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const fetchedProducts = await fetchProducts();
        const fetchedAuctions = await fetchAuctions();
        const filteredProducts = fetchedProducts.filter(
          (product) => product.userId !== userId
        );
        setProducts(filteredProducts);
        setAuctions(fetchedAuctions);

        const bids = await Promise.all(
          fetchedAuctions.map(async (auction) => {
            if (auction.highestBidId) {
              try {
                const bid = await getBidsById(auction.highestBidId);
                return { auctionId: auction._id, amount: bid.amount };
              } catch {
                return { auctionId: auction._id, amount: 0 };
              }
            }
            return { auctionId: auction._id, amount: null };
          })
        );

        const bidMap: Record<string, number> = {};
        bids.forEach(({ auctionId, amount }) => {
          bidMap[auctionId] = amount;
        });
        setHighestBids(bidMap);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    const calculateTimeLeft = (auction: Auction) => {
      const now = new Date();
      const endTime = new Date(auction.endTime);
      const difference = endTime.getTime() - now.getTime();

      if (difference <= 0) {
        const updatedAuction: Partial<Auction> = {
          status: 'closed',
        };
        patchAuction(auction?._id || '', updatedAuction);
        return 'Auction ended';
      }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor(
        (difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
      );
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      return `${days}d ${hours}h ${minutes}m ${seconds}s`;
    };

    const intervalId = setInterval(() => {
      const updatedTimeLeft = { ...timeLeftMap };

      auctions.forEach((auction) => {
        updatedTimeLeft[auction._id] = calculateTimeLeft(auction);
      });

      setTimeLeftMap(updatedTimeLeft);
    }, 1000);

    return () => clearInterval(intervalId);
  }, [auctions, timeLeftMap]);

  const handleBidClick = (auctionId: string, productId: string) => {
    navigate(`/products/${auctionId}/${productId}`);
  };

  // Filter products by search query
  const filteredProducts = products.filter((product) =>
    product.itemName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortCriteria) {
      case 'itemName':
        return a.itemName.localeCompare(b.itemName);
      case 'minprice':
        return a.minprice - b.minprice;
      default:
        return 0;
    }
  });

  // Pagination logic
  const totalPages = Math.ceil(sortedProducts.length / itemsPerPage);
  const paginatedProducts = sortedProducts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handlePageChange = (event: React.ChangeEvent<unknown>, value: number) => {
    setCurrentPage(value);
  };

  return (
    <Box sx={{ padding: '2rem', overflow: 'auto' }}>
      {/* Search Bar and Sort Dropdown */}
      <Box sx={{ display: 'flex', alignItems: 'center', marginBottom: '1rem' }}>
        <TextField
          placeholder={t('searchProducts')} // Use translation key
          variant="outlined"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          sx={{ flex: 1, marginRight: '1rem' }}
        />
        <FormControl variant="outlined" size="small" sx={{ minWidth: 200 }}>
          <InputLabel>{t('sortBy')}</InputLabel> {/* Use translation key */}
          <Select
            value={sortCriteria}
            onChange={(e) => setSortCriteria(e.target.value)}
            label={t('sortBy')} // Use translation key
          >
            <MenuItem value="">{t('none')}</MenuItem> {/* Use translation key */}
            <MenuItem value="itemName">{t('itemName')}</MenuItem> {/* Use translation key */}
            <MenuItem value="minprice">{t('price')}</MenuItem> {/* Use translation key */}
          </Select>
        </FormControl>
      </Box>

      {paginatedProducts.map((product) => {
        const auction = auctions.find((auc) => auc.productId === product._id);
        if (!auction || auction.status !== 'active') {
          return null;
        }
        const timeLeft = auction ? timeLeftMap[auction._id] : t('loading'); // Use translation key
        const highestBid = auction ? highestBids[auction._id] : null;

        return (
          <Card
            key={product._id}
            sx={{
              display: 'flex',
              marginBottom: '2rem',
              width: '90vw',
              boxShadow: '0 2px 5px rgba(0,0,0,0.1)',
            }}
          >
            <CardMedia
              component="img"
              sx={{ width: 151, padding: 2 }}
              image={product.images?.[0] || 'app/src/assets/react.svg'}
              alt={product.itemName}
            />
            <Box sx={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
              <Typography
                sx={{ marginTop: '1rem', marginLeft: '1rem' }}
                component="div"
                variant="h5"
              >
                {product.itemName}
              </Typography>
              <CardContent
                sx={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  gap: '1rem',
                  padding: '1rem',
                }}
              >
                <Typography variant="subtitle1" sx={{ color: 'text.secondary' }}>
                  {t('category')}: {product.category}
                </Typography>
                <Typography variant="subtitle1" sx={{ color: 'text.secondary' }}>
                  {t('description')}: {product.description}
                </Typography>
                <Typography variant="subtitle1" sx={{ color: 'text.secondary' }}>
                  {t('startTime')}: {auction ? new Date(auction.startTime).toLocaleString() : t('loading')}
                </Typography>
                <Typography variant="subtitle1" sx={{ color: 'text.secondary' }}>
                  {t('endTime')}: {timeLeft}
                </Typography>
                <Typography variant="subtitle1" sx={{ color: 'text.secondary' }}>
                  {t('basePrice')}: ${product.minprice || 'N/A'}
                </Typography>
                <Typography variant="subtitle1" sx={{ color: 'text.secondary' }}>
                  {t('highestBid')}: {highestBid !== undefined && highestBid !== null ? `$${highestBid}` : t('noBidsYet')}
                </Typography>
              </CardContent>
              <Box sx={{ margin: '1rem' }}>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => handleBidClick(auction?._id || '', product._id)}
                >
                  {t('placeUpdateBid')}
                </Button>
              </Box>
            </Box>
          </Card>
        );
      })}

      {/* Pagination */}
      <Box sx={{ display: 'flex', justifyContent: 'center', marginTop: '2rem' }}>
        <Pagination
          count={totalPages}
          page={currentPage}
          onChange={handlePageChange}
          color="primary"
        />
      </Box>
    </Box>
  );
};

export default Homepage;
