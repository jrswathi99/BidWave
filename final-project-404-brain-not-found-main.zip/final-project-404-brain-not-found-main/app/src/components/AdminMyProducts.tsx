import React, { useEffect, useState } from 'react';
import { Box, Typography, Grid, Card, CardContent, CardMedia, Button } from '@mui/material';
import { fetchProducts, deleteProduct } from '../services/product-service'; // API functions for product operations
import { fetchUsers } from '../services/adminpage-services'; // Fetch users
import { Product } from '../models/Products';
import { useTranslation } from 'react-i18next';

// Define the User interface
interface User {
  _id: string;
  username: string;
  email: string;
  role?: string; // Optional role field (e.g., admin or user)
}

const AdminMyProducts: React.FC = () => {
  const { t } = useTranslation(); // Translation hook
  const [products, setProducts] = useState<Product[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const ADMIN_EMAIL = 'admin404@gmail.com';
  const ADMIN_PASSWORD = 'admin@404'; // Admin credentials for bypass

  useEffect(() => {
    const fetchAllData = async () => {
      try {
        // Fetch all products
        const fetchedProducts = await fetchProducts(ADMIN_EMAIL, ADMIN_PASSWORD);
        setProducts(fetchedProducts);

        // Fetch all users
        const fetchedUsers = await fetchUsers(ADMIN_EMAIL, ADMIN_PASSWORD);
        setUsers(fetchedUsers.data || fetchedUsers); // Adjust based on API response
      } catch (err: any) {
        console.error('Error fetching data:', err);
        setError(err.message || 'An error occurred while fetching data.');
      } finally {
        setLoading(false);
      }
    };

    fetchAllData();
  }, []);

  const getUserById = (userId: string): User | undefined => {
    return users.find((user) => user._id === userId);
  };

  const handleDeleteProduct = async (productId: string) => {
    try {
      if (!productId) {
        console.error('Invalid product ID provided. Deletion aborted.');
        alert('Unable to delete product. Product ID is missing.');
        return;
      }

      // Direct API call for product deletion
      await deleteProduct(productId, {
        adminEmail: ADMIN_EMAIL,
        adminPassword: ADMIN_PASSWORD,
      });

      // Remove the deleted product from the local state
      setProducts((prevProducts) =>
        prevProducts.filter((product) => product._id !== productId)
      );

      alert('Product deleted successfully.');
    } catch (error) {
      console.error('Error deleting product:', error);
      alert('Failed to delete product. Please try again.');
    }
  };

  return (
    <Box sx={{ padding: 2 }}>
      <Typography variant="h6" gutterBottom>
        {t('allProducts')}
      </Typography>

      {loading && <Typography>{t('loading')}</Typography>}
      {error && <Typography color="error">{error}</Typography>}

      <Grid container spacing={3}>
        {products.map((product) => {
          const user = getUserById(product.userId); // Find the user who added the product
          return (
            <Grid item xs={12} sm={6} md={4} key={product._id}>
              <Card sx={{ height: '100%' }}>
                <CardMedia
                  component="img"
                  height="140"
                  image={product.images[0] || 'https://via.placeholder.com/150'}
                  alt={product.itemName}
                />
                <CardContent>
                  <Typography variant="h6">{product.itemName}</Typography>
                  <Typography variant="body2" color="text.secondary">
                    {product.description}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {t('category')}: {product.category}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {t('minimumPrice')}: {product.minprice}
                  </Typography>
                  {user && (
                    <>
                      <Typography variant="body2" color="text.secondary">
                        {t('addedBy')}: {user.username}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {t('email')}: {user.email}
                      </Typography>
                    </>
                  )}
                  <Button
                    variant="outlined"
                    onClick={() => handleDeleteProduct(product._id)}
                    sx={{ marginTop: 2 }}
                  >
                    {t('delete')}
                  </Button>
                </CardContent>
              </Card>
            </Grid>
          );
        })}
      </Grid>
    </Box>
  );
};

export default AdminMyProducts;
