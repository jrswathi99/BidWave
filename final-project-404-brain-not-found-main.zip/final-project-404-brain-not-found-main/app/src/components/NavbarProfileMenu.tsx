import React, { useState } from 'react';
import { Menu, MenuItem, IconButton, Avatar } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next'; // Import useTranslation

const NavbarProfileMenu: React.FC<{ onLogout: () => void }> = ({ onLogout }) =>{
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const navigate = useNavigate();
  const { t } = useTranslation();

  // Handle opening of the menu
  const handleOpen = (event: React.MouseEvent<HTMLElement>) => setAnchorEl(event.currentTarget);

  // Handle closing of the menu
  const handleClose = () => setAnchorEl(null);

  // Handle navigation, including logout
  const handleNavigate = (path: string) => {
    setAnchorEl(null);
    if (path === '/logout') {
      // Clear authentication status from localStorage
      localStorage.clear();
      // Redirect to login page
      onLogout();
      navigate('/login');
    } else {
      navigate(path);
    }
  };

  return (
    <>
      <IconButton onClick={handleOpen}>
        <Avatar alt="User" src="/static/images/avatar/1.jpg" />
      </IconButton>
      <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleClose}>
        <MenuItem onClick={() => handleNavigate('/profile')}>{t('profile')}</MenuItem>
        <MenuItem onClick={() => handleNavigate('/settings')}>{t('settings')}</MenuItem>

        {/* Logout menu item */}
        <MenuItem onClick={() => handleNavigate('/logout')}>{t('logout')}</MenuItem>
      </Menu>
    </>
  );
};

export default NavbarProfileMenu;