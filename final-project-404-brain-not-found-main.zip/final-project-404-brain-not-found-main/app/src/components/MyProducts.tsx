import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { TextField, Button, Box, Typography, Grid, Card, CardContent, CardMedia, Pagination, Select, MenuItem, FormControl, InputLabel } from '@mui/material';
import { fetchProductsByUser, addNewProduct, updateExistingProduct, deleteExistingProduct } from '../store/productSlice';
import { RootState, AppDispatch } from '../components/store'; // Adjust import path as per your project structure
import { Product } from '../models/Products';
import {jwtDecode} from 'jwt-decode';
import { Auction } from '../models/Auction';
import { useTranslation } from 'react-i18next';
import { addAuction } from '../services/auction-service';

type DecodedToken = {
  id: string;
  exp: number;
};

const MyProducts: React.FC = () => {
  const { t } = useTranslation(); // Translation hook
  const dispatch = useDispatch<AppDispatch>();
  const { products, loading, error } = useSelector((state: RootState) => state.products); // Accessing Redux state

  const [newProduct, setNewProduct] = useState<Product>({
    itemName: '',
    description: '',
    category: '',
    images: [],
    minprice: 0,
    userId: '',
  });

  const [userId, setUserId] = useState<string | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isFormVisible, setFormVisible] = useState<boolean>(false);
  const [updateFormVisible, setUpdateFormVisible] = useState<boolean>(false);
  const [productToUpdate, setProductToUpdate] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>(''); // Search query state
  const [sortCriteria, setSortCriteria] = useState<string>(''); // Sort criteria
  const [currentPage, setCurrentPage] = useState<number>(1); // Pagination state
  const itemsPerPage = 5; // Number of items per page

  useEffect(() => {
    const initializeUserId = async () => {
      try {
        const token = localStorage.getItem('jwtToken');
        if (!token) {
          throw new Error('No token found. Please log in.');
        }

        const decodedToken = jwtDecode<DecodedToken>(token);
        const loggedInUserId = decodedToken.id;
        setUserId(loggedInUserId);

        dispatch(fetchProductsByUser(loggedInUserId)); // Fetch products using Redux
      } catch (err: any) {
        console.error(err);
      }
    };

    initializeUserId();
  }, [dispatch]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewProduct({ ...newProduct, [name]: value });
  };

  const handleImageChange = async () => {
    try {
      if ('showOpenFilePicker' in window) {
        const [fileHandle] = await (window as any).showOpenFilePicker();
        const file = await fileHandle.getFile();
        const reader = new FileReader();
        reader.onloadend = () => {
          setImagePreview(reader.result as string);
          setNewProduct({
            ...newProduct,
            images: [reader.result as string]
          });
        };
        reader.readAsDataURL(file);
      } else {
        alert('File System Access API is not supported in your browser.');
      }
    } catch (error) {
      console.error('Error opening file:', error);
    }
  };

  const handleUpdateImageChange = async () => {
    try {
      if ('showOpenFilePicker' in window) {
        const [fileHandle] = await (window as any).showOpenFilePicker();
        const file = await fileHandle.getFile();
        const reader = new FileReader();
        reader.onloadend = () => {
          setProductToUpdate((prev) =>
            prev ? { ...prev, images: [reader.result as string] } : null
          );
        };
        reader.readAsDataURL(file);
      } else {
        alert('File System Access API is not supported in your browser.');
      }
    } catch (error) {
      console.error('Error opening file:', error);
    }
  };

  const handleAddProduct = async () => {
    try {
      if (!userId) throw new Error('User not logged in.');
      // Validate minimum price before submitting
      const parsedMinPrice = parseFloat(newProduct.minprice.toString());
      if (isNaN(parsedMinPrice)) {
        alert('Minimum price must be a valid number.');
        return;
      }
      const productWithUserID = { ...newProduct, userId: userId };
      const response = await dispatch(addNewProduct(productWithUserID));
      setNewProduct({ itemName: '', description: '', category: '', images: [], minprice: 0, userId: '' });
      const payload = response.payload as Product;
      if (payload._id) {
        const endTime = new Date();
        endTime.setDate(endTime.getDate() + 7); // Set end time to 7 days later
        const auction: Auction = {
          productId: payload._id,  // Reference to the product ID
          startPrice: payload.minprice,          // Starting price of the auction
          sellerId: userId,    // Reference to the user ID of the seller
          startTime: new Date(),    // Auction start time
          endTime: endTime, // End time (7 days later)
          status: 'active',         // Auction status (active, closed, or pending)
          bids: []                  // Optional array of bids (empty in this case)
        };
        await addAuction(auction);
      }
      setImagePreview(null);
      setFormVisible(false);
    } catch (err: any) {
      console.error(err);
    }
  };
  const getMaxDate = () => {
    const maxDate = new Date();
    maxDate.setDate(maxDate.getDate() + 7);
    return maxDate.toISOString().slice(0, 16); // Returns the date in the format YYYY-MM-DDTHH:MM
  };

  const [endTime, setEndTime] = useState<string>(getMaxDate());

  // Handle changes in the date picker (for the new product form)
  const handleEndTimeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEndTime(e.target.value);
  };

  const showUpdateForm = (product: Product) => {
    setProductToUpdate(product);
    setUpdateFormVisible(true);
  };

  const handleUpdateFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (productToUpdate) {
      const { name, value, files } = e.target;
      setProductToUpdate({
        ...productToUpdate,
        [name]: files ? files[0] : value
      });
    }
  };

  const handleUpdateProduct = async () => {
    if (productToUpdate && productToUpdate._id) {
      try {
        const token = localStorage.getItem('jwtToken');
        if (!token) {
          throw new Error('No token found. Please log in.');
        }

        // Validate minimum price before submitting
        const parsedMinPrice = parseFloat(productToUpdate.minprice.toString());
        if (isNaN(parsedMinPrice)) {
          alert('Minimum price must be a number.');
          return;
        }
        await dispatch(updateExistingProduct({ productId: productToUpdate._id, product: productToUpdate, token }));
        setUpdateFormVisible(false);
        setProductToUpdate(null);
      } catch (error) {
        console.error(error);
      }
    }
  };

  const handleDeleteProduct = (productId?: string) => {
    if (!productId) return;
    const token = localStorage.getItem('jwtToken');
    if (!token) throw new Error('No token found. Please log in.');
    dispatch(deleteExistingProduct({ productId, token }));
  };

  const toggleFormVisibility = () => {
    setFormVisible(!isFormVisible);
  };

  const handleShareProduct = async (product: Product) => {
    try {
      if (navigator.share) {
        const productDetails = `
          ${t('itemName')}: ${product.itemName}
          ${t('description')}: ${product.description}
          ${t('category')}: ${product.category}
          ${t('minimumPrice')}: ${product.minprice}
        `;

        await navigator.share({
          title: product.itemName,
          text: productDetails,
          url: `${window.location.origin}/products/${product._id}`, // Include product ID in the URL
        });
        console.log('Product shared successfully');
      } else {
        alert('Web Share API is not supported in your browser.');
      }
    } catch (error) {
      console.error('Error sharing product:', error);
    }
  };

  // Filter products based on the search query
  const filteredProducts = (products || []).filter((product) =>
    product.itemName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortCriteria) {
      case 'itemName':
        return a.itemName.localeCompare(b.itemName);
      case 'minprice':
        return a.minprice - b.minprice;
      case 'category':
        return a.category.localeCompare(b.category);
      default:
        return 0;
    }
  });

  // Pagination logic
  const totalPages = Math.ceil(sortedProducts.length / itemsPerPage);
  const paginatedProducts = sortedProducts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handlePageChange = (event: React.ChangeEvent<unknown>, value: number) => {
    setCurrentPage(value);
  };

  return (
    <Box sx={{ padding: 2 }}>
      <Button variant="contained" onClick={toggleFormVisibility} sx={{ marginBottom: 3 }}>
        {isFormVisible ? t('cancel') : t('addProduct')}
      </Button>

      {isFormVisible && (
        <Box sx={{ marginBottom: 3 }}>
          <Typography variant="h6">{t('createNewProduct')}</Typography>
          <TextField
            label={t('itemName')}
            name="itemName"
            value={newProduct.itemName}
            onChange={handleInputChange}
            fullWidth
            required
            sx={{ marginBottom: 2 }}
          />
          <TextField
            label={t('category')}
            name="category"
            value={newProduct.category}
            onChange={handleInputChange}
            fullWidth
            required
            sx={{ marginBottom: 2 }}
          />
          <TextField
            label={t('description')}
            name="description"
            value={newProduct.description}
            onChange={handleInputChange}
            fullWidth
            sx={{ marginBottom: 2 }}
          />
          <TextField
            label={t('minimumPrice')}
            name="minprice"
            value={newProduct.minprice}
            onChange={handleInputChange}
            fullWidth
            sx={{ marginBottom: 2 }}
          />
          <TextField
            label="End Time"
            type="datetime-local"
            value={endTime}
            onChange={handleEndTimeChange}
            fullWidth
            required
            sx={{ marginBottom: 2 }}
            inputProps={{
              min: new Date().toISOString().slice(0, 16), // Prevent selecting past times
              max: getMaxDate(), // Limit the date to 7 days from now
            }}
            disabled={updateFormVisible} // Disable if it's the update form
          />
          <Button variant="outlined" component="label" sx={{ marginBottom: 0, marginRight: 2 }} onClick={handleImageChange}>
            {t('uploadImage')}
          </Button>
          {imagePreview && (
            <Box sx={{ marginBottom: 0 }}>
              <Typography variant="body2">{t('imagePreview')}:</Typography>
              <img
                src={imagePreview}
                alt="Product Preview"
                style={{ maxWidth: '200px', marginTop: '10px', objectFit: 'cover' }}
              />
            </Box>
          )}
          <Button variant="contained" onClick={handleAddProduct}>
            {t('addProduct')}
          </Button>
        </Box>
      )}

      {updateFormVisible && productToUpdate && (
        <Box sx={{ marginBottom: 3 }}>
          <Typography variant="h6">{t('updateProduct')}</Typography>
          <TextField
            label={t('itemName')}
            name="itemName"
            value={productToUpdate.itemName}
            onChange={handleUpdateFormChange}
            fullWidth
            required
            sx={{ marginBottom: 2 }}
          />
          <TextField
            label={t('category')}
            name="category"
            value={productToUpdate.category}
            onChange={handleUpdateFormChange}
            fullWidth
            required
            sx={{ marginBottom: 2 }}
          />
          <TextField
            label={t('description')}
            name="description"
            value={productToUpdate.description || ''}
            onChange={handleUpdateFormChange}
            fullWidth
            sx={{ marginBottom: 2 }}
          />
          <TextField
            label={t('minimumPrice')}
            name="minprice"
            value={productToUpdate.minprice}
            onChange={handleUpdateFormChange}
            fullWidth
            sx={{ marginBottom: 2 }}
          />
          <Button variant="outlined" component="label" sx={{ marginBottom: 0, marginRight: 2 }} onClick={handleUpdateImageChange}>
            {t('uploadImage')}
          </Button>
          {productToUpdate?.images[0] && (
            <Box sx={{ marginBottom: 2 }}>
              <Typography variant="body2">{t('imagePreview')}:</Typography>
              <img
                src={productToUpdate.images[0]}
                alt="Updated Product Preview"
                style={{ maxWidth: '200px', marginTop: '10px', objectFit: 'cover' }}
              />
            </Box>
          )}
          <Button variant="contained" onClick={handleUpdateProduct}>
            {t('updateProduct')}
          </Button>
        </Box>
      )}

      <Typography variant="h6" gutterBottom>
        {t('allProducts')}
      </Typography>
      {/* Search Bar and Sort Dropdown */}
      <Box sx={{ display: 'flex', alignItems: 'center', marginBottom: '1rem' }}>
        <TextField
          placeholder={t('searchYourProducts')} // Use translation key
          variant="outlined"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          sx={{ flex: 1, marginRight: '1rem' }}
        />
        <FormControl variant="outlined" size="small" sx={{ minWidth: 200 }}>
          <InputLabel>{t('sortBy')}</InputLabel> {/* Use translation key */}
          <Select
            value={sortCriteria}
            onChange={(e) => setSortCriteria(e.target.value)}
            label={t('sortBy')} // Use translation key
          >
            <MenuItem value="">{t('none')}</MenuItem> {/* Use translation key */}
            <MenuItem value="itemName">{t('itemName')}</MenuItem> {/* Use translation key */}
            <MenuItem value="minprice">{t('price')}</MenuItem> {/* Use translation key */}
            <MenuItem value="category">{t('category')}</MenuItem> {/* Use translation key */}
          </Select>
        </FormControl>
      </Box>

      <Grid container spacing={3}>
        {paginatedProducts.map((product) => (
          <Grid item xs={12} sm={6} md={4} key={product._id}>
            <Card sx={{ height: '100%' }}>
              <CardMedia
                component="img"
                height="140"
                image={product.images[0] || 'https://via.placeholder.com/150'}
                alt={product.itemName}
              />
              <CardContent>
                <Typography variant="h6">{product.itemName}</Typography>
                <Typography variant="body2" color="text.secondary">
                  {product.description}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {t('category')}: {product.category}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {t('minimumPrice')}: {product.minprice}
                </Typography>
                <Button variant="outlined" onClick={() => showUpdateForm(product)} sx={{ marginTop: 2 }}>
                  {t('update')}
                </Button>
                <Button variant="outlined" onClick={() => handleDeleteProduct(product._id)} sx={{ marginTop: 2 }}>
                  {t('delete')}
                </Button>
                <Button variant="outlined" onClick={() => handleShareProduct(product)} sx={{ marginTop: 2 }}>
                  {t('share')}
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Pagination */}
      <Box sx={{ display: 'flex', justifyContent: 'center', marginTop: '2rem' }}>
        <Pagination
          count={totalPages}
          page={currentPage}
          onChange={handlePageChange}
          color="primary"
        />
      </Box>
    </Box>
  );
};

export default MyProducts;