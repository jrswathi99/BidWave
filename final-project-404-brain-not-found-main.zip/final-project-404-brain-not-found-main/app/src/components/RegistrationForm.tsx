import React, { useState } from "react";
import {
  Box,
  Button,
  TextField,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  Typography,
  SelectChangeEvent,
} from "@mui/material";
import { useDispatch } from "react-redux";
import { setRegistrationSuccess } from "./UserSlice.ts";
import { Link } from "react-router-dom";
import logo from '../../public/assets/logo.png'; // Import logo image
import registrationFormStyles from '../styles/RegistrationFormStyles'; // Import the external styling

interface RegistrationFormProps {
  onRegisterSuccess: () => void; // Callback triggered upon successful registration
  apiUrl: string; // API URL to send the registration data
}

const RegistrationForm: React.FC<RegistrationFormProps> = ({
  onRegisterSuccess,
  apiUrl,
}) => {
  const [formData, setFormData] = useState({
    username: "", // Changed name to username
    email: "",
    password: "",
    age: "",
    gender: "",
  });

  const [error, setError] = useState(""); // Holds error message if registration fails
  const [passwordError, setPasswordError] = useState(""); // Holds error for invalid password

  const dispatch = useDispatch();

  // Handle change for input fields (TextField)
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | { name?: string; value: unknown }>
  ) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name!]: value });

    // Validate password on change
    if (name === "password") {
      validatePassword(value as string);
    }
  };

  // Handle change specifically for Select (Gender)
  const handleSelectChange = (e: SelectChangeEvent<string>) => {
    setFormData({ ...formData, gender: e.target.value });
  };

  // Password validation function
  const validatePassword = (password: string) => {
    const minLength = 8; // Minimum length requirement
    const specialCharRegex = /[!@#$%^&*(),.?":{}|<>]/; // Regular expression for special characters

    if (password.length < minLength) {
      setPasswordError(`Password must be at least ${minLength} characters long.`);
    } else if (!specialCharRegex.test(password)) {
      setPasswordError("Password must contain at least one special character.");
    } else {
      setPasswordError(""); // No error
    }
  };

  // Handle form submission to register a new user
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordError) {
      return; // Prevent submission if the password is invalid
    }

    try {
      // Send the API request with the updated username field
      const response = await fetch(`${apiUrl}/users/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: formData.username, // Sending username instead of name
          email: formData.email,
          password: formData.password,
          age: formData.age,
          gender: formData.gender,
        }),
      });

      if (response.ok) {
        dispatch(setRegistrationSuccess(true)); // Set success in Redux
        onRegisterSuccess(); // Callback on successful registration
      } else {
        const { message } = await response.json();
        setError(message || "Registration failed!"); // Set error message if registration fails
      }
    } catch (err) {
      setError("Something went wrong. Please try again."); // Handles errors during the API request
    }
  };

  return (
    <Box sx={registrationFormStyles.container}>
      <Box sx={registrationFormStyles.paper}>
      <Box sx={registrationFormStyles.logo}>
          <img src={logo} alt="Logo" style={{ maxWidth: '200px', height: 'auto' }} />
        </Box>
        <Box
          component="form"
          onSubmit={handleSubmit}
          sx={registrationFormStyles.form}
        >
          <Typography variant="h5" sx={registrationFormStyles.formTitle}>
            Registration
          </Typography>
          {error && (
            <Typography color="error" sx={registrationFormStyles.alert}>
              {error} {/* Displays error message if any */}
            </Typography>
          )}
          <TextField
            fullWidth
            label="Username"
            name="username" // Updated to username
            value={formData.username}
            onChange={handleChange}
            margin="normal"
            required
            sx={registrationFormStyles.textField}
          />
          <TextField
            fullWidth
            label="Email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            margin="normal"
            required
            sx={registrationFormStyles.textField}
          />
          <TextField
            fullWidth
            label="Password"
            name="password"
            type="password"
            value={formData.password}
            onChange={handleChange}
            margin="normal"
            required
            error={!!passwordError} // Display error state
            helperText={passwordError} // Show validation message
            sx={registrationFormStyles.textField}
          />
          <TextField
            fullWidth
            label="Age"
            name="age"
            type="number"
            value={formData.age}
            onChange={handleChange}
            margin="normal"
            required
            sx={registrationFormStyles.textField}
          />
          <FormControl fullWidth margin="normal" sx={registrationFormStyles.textField}>
            <InputLabel>Gender</InputLabel>
            <Select
              name="gender"
              value={formData.gender}
              onChange={handleSelectChange}
              required
            >
              <MenuItem value="Male">Male</MenuItem>
              <MenuItem value="Female">Female</MenuItem>
              <MenuItem value="Other">Other</MenuItem>
            </Select>
          </FormControl>
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={registrationFormStyles.button}
          >
            Register
          </Button>
          {/* Back to Login link */}
          <Typography variant="body2" sx={registrationFormStyles.authLink}>
            Already have an account?{" "}
            <Link to="/login" style={registrationFormStyles.registerLink}>
              Back to Login
            </Link>
          </Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default RegistrationForm;
