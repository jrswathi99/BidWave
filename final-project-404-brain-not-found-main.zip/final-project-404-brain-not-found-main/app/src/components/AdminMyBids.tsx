import React, { useEffect, useState } from 'react';
import { Box, Typography, CardMedia, Button, Alert, Card } from '@mui/material';
import { getBidsById, getBidsByUserId } from '../services/bid-service';
import { fetchProductByID } from '../services/product-service';
import { getAuctionByProductId } from '../services/auction-service';
import { Auction } from '../models/Auction';
import { useNavigate } from 'react-router-dom';

const UserBidsPage = () => {
    const [bids, setBids] = useState<any[]>([]);
    const [products, setProducts] = useState<any[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [auctions, setAuctions] = useState<Auction[]>([]);
    const [highestBids, setHighestBids] = useState<Record<number, number | null>>({});
    const [timeLeftMap, setTimeLeftMap] = useState<Record<number, string>>({});
    const [isAdmin, setIsAdmin] = useState<boolean>(false); // Admin mode flag

    const ADMIN_EMAIL = "admin404@gmail.com";
    const ADMIN_PASSWORD = "admin@404"; // Admin credentials
    const token = localStorage.getItem('jwtToken');
    const navigate = useNavigate();

    useEffect(() => {
        // Determine if the user is an admin or a regular user
        const initializeMode = () => {
            if (!token) {
                setIsAdmin(true); // Admin bypass if no token
            } else {
                try {
                    const decodedToken: { id: string; role?: string } = JSON.parse(atob(token.split('.')[1])); // Decode JWT payload
                    if (decodedToken.role === 'admin') {
                        setIsAdmin(true); // Admin role detected
                    }
                } catch {
                    setIsAdmin(false); // Invalid token, fallback to regular mode
                }
            }
        };

        initializeMode();
    }, [token]);

    useEffect(() => {
        // Fetch bids placed by the user or all users for admin
        const fetchBids = async () => {
            try {
                let userBids;
                if (isAdmin) {
                    // Admin bypass: Fetch all bids (replace with an appropriate API endpoint)
                    userBids = await getBidsByUserId(ADMIN_EMAIL); // Use admin email for bypass
                } else {
                    const decodedToken: { id: string } = JSON.parse(atob(token!.split('.')[1])); // Decode JWT
                    userBids = await getBidsByUserId(decodedToken.id);
                }

                // Extract productIds from the bids
                const productIds = userBids.map((bid: any) => bid.productId);

                // Fetch product and auction details for each productId
                const productsData = await Promise.all(
                    productIds.map(async (productId: string) => {
                        const productResponse = await fetchProductByID(productId);
                        const auctionResponse = await getAuctionByProductId(productResponse._id || '');
                        return {
                            product: productResponse,
                            auction: auctionResponse,
                            bid: userBids.find((bid: any) => bid.productId === productId),
                        };
                    })
                );

                setProducts(productsData);
                setAuctions(productsData.flatMap((data) => data.auction));
            } catch (error) {
                console.error('Error fetching bids or products:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchBids();
    }, [isAdmin, token]);

    useEffect(() => {
        const calculateTimeLeft = (auction: Auction) => {
            const now = new Date();
            const endTime = new Date(auction.endTime);
            const difference = endTime.getTime() - now.getTime();

            if (difference <= 0) {
                return 'Auction ended';
            }

            const days = Math.floor(difference / (1000 * 60 * 60 * 24));
            const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((difference % (1000 * 60)) / 1000);

            return `${days}d ${hours}h ${minutes}m ${seconds}s`;
        };

        const intervalId = setInterval(() => {
            setTimeLeftMap((prev) => {
                const updatedTimeLeft = { ...prev };

                products.forEach((product) => {
                    product?.auction?.forEach((auction) => {
                        updatedTimeLeft[auction._id] = calculateTimeLeft(auction);
                    });
                });

                return updatedTimeLeft;
            });
        }, 1000);

        return () => clearInterval(intervalId);
    }, [products]);

    if (loading) {
        return <Typography variant="h6">Loading...</Typography>;
    }

    return (
        <Box sx={{ padding: '2rem' }}>
            {isAdmin && <Alert severity="info">Admin Bypass Enabled</Alert>}

            {products.length === 0 ? (
                <Alert severity="info">
                    {isAdmin ? "No bids found." : "You have not placed any bids yet."}
                </Alert>
            ) : (
                products.map((productData, index) => {
                    const auction = productData.auction.find(
                        (auc) => auc.productId === productData.product._id
                    );
                    const timeLeft = auction ? timeLeftMap[auction._id] : 'Loading...';
                    const highestBid = highestBids[auction?._id] ?? 'No bids yet';

                    return (
                        <Card
                            key={index}
                            sx={{
                                display: 'flex',
                                flexDirection: 'column',
                                marginBottom: '2rem',
                                padding: '1rem',
                                boxShadow: '0 2px 5px rgba(0,0,0,0.1)',
                            }}
                            onClick={() =>
                                navigate(`/products/${auction?._id || ''}/${productData.product._id}`)
                            }
                        >
                            <Typography variant="h5" sx={{ marginBottom: '1rem' }}>
                                {productData.product.itemName}
                            </Typography>
                            <Box sx={{ display: 'flex', gap: '1rem', marginBottom: '1rem' }}>
                                <CardMedia
                                    component="img"
                                    sx={{ width: 200, padding: 2 }}
                                    image={productData.product.images?.[0] || 'app/src/assets/react.svg'}
                                    alt={productData.product.itemName}
                                />
                                <Box
                                    sx={{
                                        display: 'grid',
                                        gridTemplateColumns: '1fr 1fr',
                                        gap: '1rem',
                                        flex: 1,
                                    }}
                                >
                                    <Typography variant="body1">
                                        Description: {productData.product.description}
                                    </Typography>
                                    <Typography variant="body1">
                                        Category: {productData.product.category}
                                    </Typography>
                                    <Typography variant="body1">
                                        Base Price: $ {productData.product.minprice}
                                    </Typography>
                                    <Typography variant="body1">
                                        Highest Bid: {typeof highestBid === 'number' ? `$${highestBid}` : highestBid}
                                    </Typography>
                                    <Typography variant="body1">
                                        Time Remaining: {timeLeft}
                                    </Typography>
                                </Box>
                            </Box>
                        </Card>
                    );
                })
            )}
        </Box>
    );
};

export default UserBidsPage;
