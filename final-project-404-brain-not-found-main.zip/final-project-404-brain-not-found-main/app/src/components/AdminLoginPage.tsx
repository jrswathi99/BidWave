import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { setRegistrationSuccess } from "./UserSlice.ts"; // Importing the action from the user slice
import {
  Box,
  Button,
  TextField,
  Typography,
  Alert,
  Container,
  Paper,
} from "@mui/material";
import loginFormStyles from "../styles/LoginFormStyles.ts"; // Importing the common login form styles
import logo from "../../public/assets/logo.png"; // Replace with the path to your logo image
import { useTranslation } from "react-i18next"; // Import useTranslation

interface LoginFormProps {
  onLoginSuccess: (token: string) => void; // Callback triggered on successful login
}

const AdminLoginForm: React.FC<LoginFormProps> = ({ onLoginSuccess }) => {
  const { t } = useTranslation(); // Translation hook
  const navigate = useNavigate(); // Hook to navigate after login
  const dispatch = useDispatch(); // Hook to dispatch actions to Redux
  const [formData, setFormData] = useState({ email: "", password: "" }); // Holds form input data
  const [error, setError] = useState(""); // Holds error message if login fails

  // Access registration success status from Redux state
  const registrationSuccess = useSelector(
    (state: any) => state.user.registrationSuccess
  );

  // Hardcoded admin credentials
  const adminCredentials = {
    email: "admin404@gmail.com",
    password: "admin@404",
  };

  // Updates form data based on user input
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handles form submission and validates user credentials
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); // Clear previous errors

    // Validate credentials
    if (
      formData.email === adminCredentials.email &&
      formData.password === adminCredentials.password
    ) {
      // Simulate token generation for admin login
      const token = "adminJwtToken"; // Example token for admin

      // Store the token in localStorage
      localStorage.setItem("jwtToken", token);

      // Calls the callback with the token
      onLoginSuccess(token);

      // Redirects to the admin dashboard
      navigate("/home");
    } else {
      setError(t("invalidEmailOrPassword")); // Use translation key
    }
  };

  // Clear the registration success message after showing it
  const clearSuccessMessage = () => {
    dispatch(setRegistrationSuccess(false));
  };

  return (
    <Container sx={loginFormStyles.container}>
      <Paper elevation={3} sx={loginFormStyles.paper}>
        <Box sx={loginFormStyles.logo}>
          <img src={logo} alt="Logo" style={loginFormStyles.logoImage} />
        </Box>

        {registrationSuccess && (
          <Alert
            severity="success"
            sx={loginFormStyles.alert}
            onClose={clearSuccessMessage} // Clear message on close
          >
            {t("userRegistrationSuccessful")} {/* Use translation key */}
          </Alert>
        )}
        <form onSubmit={handleSubmit}>
          <Typography variant="h4" gutterBottom>
            {t("adminLogin")} {/* Use translation key */}
          </Typography>
          <TextField
            fullWidth
            margin="normal"
            label={t("email")} // Use translation key
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            required
            variant="outlined"
            sx={loginFormStyles.textField}
          />
          <TextField
            fullWidth
            margin="normal"
            label={t("password")} // Use translation key
            name="password"
            type="password"
            value={formData.password}
            onChange={handleChange}
            required
            variant="outlined"
            sx={loginFormStyles.textField}
          />
          {error && (
            <Alert severity="error" sx={{ marginTop: 2 }}>
              {error}
            </Alert>
          )}
          <Button
            fullWidth
            variant="contained"
            color="primary"
            type="submit"
            sx={loginFormStyles.button}
          >
            {t("login")} {/* Use translation key */}
          </Button>
        </form>

        <Typography variant="body2" align="center" sx={{ marginTop: 2 }}>
          <Link to="/login" style={{ textDecoration: "none", color: "#1976d2" }}>
            {t("userLogin")} {/* Use translation key */}
          </Link>
        </Typography>
      </Paper>
    </Container>
  );
};

export default AdminLoginForm;