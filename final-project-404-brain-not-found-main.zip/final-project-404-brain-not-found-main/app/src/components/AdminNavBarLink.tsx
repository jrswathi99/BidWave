import React, { useState } from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next'; // Import useTranslation

interface NavbarLinksProps {
  onPageSwitch: (page: string) => void;
}

const NavbarLinks: React.FC<NavbarLinksProps> = ({ onPageSwitch }) => {
  const { t } = useTranslation(); // Translation hook
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    setAnchorEl(null);
    navigate(path);
  };

  return (
    <>
      <Button color="inherit" onClick={() => handleNavigate('/home')} >{t('home')}</Button>
      
      <Button color="inherit" onClick={() => handleNavigate('/mybids')}>{t('myBids')}</Button>
      
      <Button color="inherit" onClick={()=> handleNavigate('/myproducts')}>{t('Products')}</Button>
    </>
  );
};

export default NavbarLinks;