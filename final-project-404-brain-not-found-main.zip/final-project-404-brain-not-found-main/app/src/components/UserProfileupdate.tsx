// src/components/FormPropsTextFields.tsx

import React, { useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { jwtDecode } from 'jwt-decode'; // Corrected import
import { fetchUserById, updateUserById } from '../services/profileupdate-service';
import { useTranslation } from 'react-i18next'; // Import useTranslation
import { profileContainer, profileImage, formContainer, heading, inputFields, button } from '../styles/ProfileStyle.ts'; // Import styles
import malelogo from "../assets/man.png"; // Replace with the path to your logo image
import femalelogo from "../assets/girl.png"; // Replace with the path to your logo image

const options = [
  { value: 'Male', label: 'Male' },
  { value: 'Female', label: 'Female' },
  { value: 'Other', label: 'Other' },
];

type FormData = {
  username: string;
  email: string;
  password?: string; // Optional password
  gender: string;
  age: string;
};

type DecodedToken = {
  id: string; // Match the payload structure of your JWT token
  exp: number; // Expiration timestamp (optional, based on your JWT)
};

export default function FormPropsTextFields() {
  const { t } = useTranslation(); // Translation hook
  const [formData, setFormData] = useState<FormData>({
    username: '',
    email: '',
    password: '',
    gender: '',
    age: '',
  });
  const [userId, setUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    const initializeUserId = async () => {
      try {
        setLoading(true);

        // Retrieve JWT token from localStorage
        const token = localStorage.getItem('jwtToken');
        if (!token) {
          throw new Error('No token found. Please log in.');
        }

        // Decode the JWT to extract the user ID
        const decodedToken = jwtDecode<DecodedToken>(token);

        // Set the logged-in user's ID
        const loggedInUserId = decodedToken.id;
        setUserId(loggedInUserId);

        // Fetch user data based on decoded user ID
        const user = await fetchUserById(loggedInUserId, token); // Pass token to fetchUserById
        setFormData({
          username: user.username || '',
          email: user.email || '',
          password: '', // Do not prefill the password
          gender: user.gender || '',
          age: user.age || '',
        });

        setLoading(false);
      } catch (err: any) {
        console.error(err);
        setError(err.message || t('profileUpdateFailed')); // Use translation key
        setLoading(false);
      }
    };

    initializeUserId();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    try {
      setError('');
      setSuccess('');
      const payload = { ...formData }; // Include all fields, including password
  
      const token = localStorage.getItem('jwtToken'); // Get the token for the update request
      if (!token) {
        throw new Error('No token found. Please log in.');
      }
  
      if (userId) {
        await updateUserById(userId, payload, token); // Pass token to updateUserById
        setSuccess(t('profileUpdated')); // Use translation key
      }
    } catch (err: any) {
      console.error(err);
      const errorMessage = err.response?.data?.message || t('profileUpdateFailed'); // Use translation key
      setError(errorMessage);
    }
  };

  if (loading) return <Typography>{t('loading')}</Typography>; // Use translation key
  if (error) return <Typography color="error">{error}</Typography>;

  return (
    <Box sx={profileContainer}>
      {/* Conditional profile image based on gender */}
      <img
        src={formData.gender === 'Female' ? `${femalelogo}` : `${malelogo}`} 
        alt="Profile"
        style={profileImage}
      />
      <Box sx={formContainer} component="form" noValidate autoComplete="off">
        <Typography sx={heading} variant="h4" component="h1" gutterBottom>
          {t('profile')} {/* Use translation key */}
        </Typography>

        {error && <Typography color="error">{error}</Typography>}
        {success && <Typography color="success.main">{success}</Typography>}

        <TextField
          required
          id="username"
          name="username"
          label={t('username')}
          value={formData.username}
          onChange={handleChange}
          helperText={t('enterUsername')}
          sx={inputFields}
        />

        <TextField
          id="gender"
          name="gender"
          select
          label={t('gender')}
          value={formData.gender}
          onChange={handleChange}
          helperText={t('selectGender')}
          sx={inputFields}
        >
          {options.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          required
          id="age"
          name="age"
          label={t('age')}
          type="number"
          value={formData.age}
          onChange={handleChange}
          helperText={t('enterAge')}
          sx={inputFields}
        />

        <TextField
          required
          id="email"
          name="email"
          type="email"
          label={t('email')}
          value={formData.email}
          onChange={handleChange}
          helperText={t('enterEmail')}
          sx={inputFields}
        />

        <TextField
          id="password"
          name="password"
          type="password"
          label={t('password')}
          value={formData.password}
          onChange={handleChange}
          helperText={t('enterNewPassword')}
          sx={inputFields}
        />

        <Button variant="contained" sx={button} onClick={handleSubmit}>
          {t('update')} {/* Use translation key */}
        </Button>
      </Box>
    </Box>
  );
}
