import React from 'react';
import { TextField, InputAdornment } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import { useTranslation } from 'react-i18next';

const NavbarSearch: React.FC = () => {
  const { t } = useTranslation(); 
  return (
    <TextField
      placeholder={t('searchItems')}
      size="small"
      fullWidth
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            <SearchIcon />
          </InputAdornment>
        ),
      }}
      sx={{ background: '#fff', borderRadius: 1 }}
    />
  );
};

export default NavbarSearch;
