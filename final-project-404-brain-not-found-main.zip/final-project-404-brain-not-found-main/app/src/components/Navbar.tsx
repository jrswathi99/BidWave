import React from 'react';
import { AppBar, Toolbar, Typography, Box } from '@mui/material';
import NavbarLinks from './NavbarLinks';
import NavbarProfileMenu from './NavbarProfileMenu';

const Navbar: React.FC<{ onLogout: () => void }> = ({ onLogout }) => {
  return (
    <>
      <AppBar position="sticky">
        <Toolbar>
          {/* Logo */}
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            BidWave
          </Typography>

          {/* Links */}
          <Box sx={{ flexGrow: 1, display: 'flex', justifyContent: 'space-evenly' }}>
            <NavbarLinks />
          </Box>

          {/* Profile Menu */}
          <NavbarProfileMenu onLogout={onLogout} />
        </Toolbar>
      </AppBar>
    </>
  );
};

export default Navbar;
