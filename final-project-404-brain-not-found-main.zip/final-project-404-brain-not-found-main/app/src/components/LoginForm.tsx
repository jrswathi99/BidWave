import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { Link } from 'react-router-dom';
import { setRegistrationSuccess } from "./UserSlice.ts"; 
import { Box, Button, TextField, Typography, Alert, Container, Paper, useTheme } from "@mui/material";
import logo from '../../public/assets/logo.png'; // Import logo image
import loginFormStyles from '../styles/LoginFormStyles.ts'; // Import the external styling

interface LoginFormProps {
  apiUrl: string;
  onLoginSuccess: (token: string) => void;
}

const LoginForm: React.FC<LoginFormProps> = ({ apiUrl, onLoginSuccess }) => {
  const navigate = useNavigate(); 
  const dispatch = useDispatch(); 
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const registrationSuccess = useSelector((state: any) => state.user.registrationSuccess);
  
  const theme = useTheme(); // Access the current theme (light/dark)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); 

    try {
      const response = await axios.post(`${apiUrl}/users/login`, {
        email: formData.email,
        password: formData.password,
      });

      if (response.status === 200) {
        const { token } = response.data; 
        localStorage.setItem("jwtToken", token);
        onLoginSuccess(token);
        navigate("/home");
      }
    } catch (err) {
      if (axios.isAxiosError(err) && err.response) {
        setError(err.response.data.message || "Invalid email or password.");
      } else {
        setError("Error logging in. Please try again.");
      }
    }
  };

  const clearSuccessMessage = () => {
    dispatch(setRegistrationSuccess(false));
  };

  return (
    <Container sx={loginFormStyles.container}>
      <Paper elevation={3} sx={loginFormStyles.paper}>
        <Box sx={loginFormStyles.logo}>
          <img src={logo} alt="Logo" style={{ maxWidth: '200px', height: 'auto' }} />
        </Box>
  
        {registrationSuccess && (
          <Alert severity="success" sx={loginFormStyles.alert} onClose={clearSuccessMessage}>
            User registration successful!
          </Alert>
        )}
  
        <form onSubmit={handleSubmit} style={loginFormStyles.form}>
          <Typography variant="h5" sx={loginFormStyles.formTitle}>
            User Login
          </Typography>
  
          <TextField
            fullWidth
            margin="normal"
            label="Email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            required
            variant="outlined"
            sx={loginFormStyles.textField}
          />
          <TextField
            fullWidth
            margin="normal"
            label="Password"
            name="password"
            type="password"
            value={formData.password}
            onChange={handleChange}
            required
            variant="outlined"
            sx={loginFormStyles.textField}
          />
  
          {error && (
            <Alert severity="error" sx={{ marginTop: 2 }}>
              {error}
            </Alert>
          )}
  
          <Button
            fullWidth
            variant="contained"
            color="primary"
            type="submit"
            sx={loginFormStyles.button}
          >
            Login
          </Button>
        </form>
  
        <Typography variant="body2" align="center" sx={{ marginTop: 2 }}>
          Don't have an account?{" "}
          <Link to="/register" sx={loginFormStyles.registerLink}>
            Register here
          </Link>
        </Typography>
  
        <Typography variant="body2" align="center" sx={loginFormStyles.authLink}>
          <Link to="/adminlogin" sx={loginFormStyles.registerLink}>
            Admin Login
          </Link>
        </Typography>
      </Paper>
    </Container>
  );
  
};

export default LoginForm;
