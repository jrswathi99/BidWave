import axios from 'axios';

const API_BASE_URL = 'http://localhost:3002';

const api = axios.create({
    baseURL: API_BASE_URL,
});

/**
 * Fetches all users from the backend with admin bypass support.
 * @param email - Admin email for authentication bypass.
 * @param password - Admin password for authentication bypass.
 * @returns A list of all users.
 */
export const fetchUsers = async (email: string, password: string) => {
    const response = await api.get('/users', {
        headers: {
            email, // Admin email
            password, // Admin password
        },
    });
    return response.data;
};

/**
 * Deletes a specific user by ID with admin bypass support.
 * @param userId - The ID of the user to delete.
 * @param email - Admin email for authentication bypass.
 * @param password - Admin password for authentication bypass.
 */
export const deleteUser = async (userId: string, email: string, password: string) => {
    const response = await api.delete(`/users/${userId}`, {
        headers: {
            email, // Admin email
            password, // Admin password
        },
    });
    return response.data;
};

/**
 * Fetches all products with admin bypass support.
 * @param email - Admin email for authentication bypass.
 * @param password - Admin password for authentication bypass.
 * @returns A list of all products.
 */
export const fetchProducts = async (email: string, password: string) => {
    // Check for admin bypass credentials
    if (!email || !password) {
        throw new Error('Admin credentials are required for bypass');
    }

    const response = await api.get('/products', {
        headers: {
            email, // Admin email
            password, // Admin password
        },
    });
    return response.data;
};

/**
 * Fetches all auctions with admin bypass support.
 * @param email - Admin email for authentication bypass.
 * @param password - Admin password for authentication bypass.
 * @returns A list of all auctions.
 */
export const fetchAuctions = async (email: string, password: string) => {
    // Check for admin bypass credentials
    if (!email || !password) {
        throw new Error('Admin credentials are required for bypass');
    }

    const response = await api.get('/auctions', {
        headers: {
            email, // Admin email
            password, // Admin password
        },
    });
    return response.data;
};
