import axios from 'axios'; // For HTTP requests
import { Auction } from '../models/Auction.ts'; // Auction model
import {jwtDecode} from 'jwt-decode'; // For decoding JWT tokens

interface DecodedToken {
    id: string;
    exp: number;
    // Add other fields if necessary
}

const BASE_URL = 'http://localhost:3002/auctions'; // API base URL

const ADMIN_EMAIL = "admin404@gmail.com";
const ADMIN_PASSWORD = "admin@404"; // Admin credentials for fallback

export const addAuction = async (auction: Auction): Promise<Auction> => {
    try {
        const token = localStorage.getItem('jwtToken') || `${ADMIN_EMAIL}:${ADMIN_PASSWORD}`;

        const response = await axios.post(BASE_URL, auction, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
        });

        return response.data;
    } catch (error) {
        console.error('Error adding auction:', error);
        throw error;
    }
};

export const getAuctionById = async (auctionId: string): Promise<Auction> => {
    try {
        const token = localStorage.getItem('jwtToken') || `${ADMIN_EMAIL}:${ADMIN_PASSWORD}`;

        const response = await axios.get(`${BASE_URL}/${auctionId}`, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
        });

        return response.data;
    } catch (error) {
        console.error('Error fetching auction by ID:', error);
        throw error;
    }
};

export const getAuctionByProductId = async (productId: string): Promise<Auction> => {
    try {
        const token = localStorage.getItem('jwtToken') || `${ADMIN_EMAIL}:${ADMIN_PASSWORD}`;

        const response = await axios.get(`${BASE_URL}/product/${productId}`, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
        });

        return response.data;
    } catch (error) {
        console.error('Error fetching auction by product ID:', error);
        throw error;
    }
};

export const patchAuction = async (auctionId: string, updatedAuction: Partial<Auction>): Promise<Auction> => {
    try {
        const token = localStorage.getItem('jwtToken') || `${ADMIN_EMAIL}:${ADMIN_PASSWORD}`;

        const response = await axios.patch(`${BASE_URL}/${auctionId}`, updatedAuction, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
        });

        return response.data;
    } catch (error) {
        console.error('Error updating auction:', error);
        throw error;
    }
};
