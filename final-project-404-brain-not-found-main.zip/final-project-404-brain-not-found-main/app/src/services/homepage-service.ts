import axios from 'axios';

const API_BASE_URL = 'http://localhost:3002';

const api = axios.create({
    baseURL: API_BASE_URL,
});

export const fetchProducts = async () => {
    const token = localStorage.getItem('jwtToken');
    if (!token) {
        throw new Error('No token found');
    }
    const response = await api.get('/products', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    });
    return response.data;
};

export const fetchAuctions = async () => {
    const token = localStorage.getItem('jwtToken');
    if (!token) {
        throw new Error('No token found');
    }
    const response = await api.get('/auctions', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    });
    return response.data;
};
