import axios from 'axios';

const API_BASE_URL = 'http://localhost:3002/users';

// Helper function to get the Authorization header
const getAuthHeader = () => {
  const token = localStorage.getItem('jwtToken'); // Retrieve the token from localStorage
  return token ? { Authorization: `Bearer ${token}` } : {}; // Return Authorization header if token exists
};

export const fetchAllUsers = async () => {
  try {
    const response = await axios.get(API_BASE_URL, {
      headers: {
        ...getAuthHeader(), // Include the Authorization header
      },
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching all users:', error);
    throw new Error('Failed to fetch users.');
  }
};

export const fetchUserById = async (userId: string) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/${userId}`, {
      headers: {
        ...getAuthHeader(), // Include the Authorization header
      },
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching user data:', error);
    throw new Error('Failed to fetch user data.');
  }
};

export const updateUserById = async (userId: string, payload: any) => {
  try {
    await axios.put(`${API_BASE_URL}/${userId}`, payload, {
      headers: {
        ...getAuthHeader(), // Include the Authorization header
      },
    });
  } catch (error) {
    console.error('Error updating user data:', error);
    throw new Error('Failed to update user data.');
  }
};
