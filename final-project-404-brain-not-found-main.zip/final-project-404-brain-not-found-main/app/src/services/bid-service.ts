// product-service.ts
import { Auction } from '../models/Auction.ts';
import { jwtDecode } from 'jwt-decode';
import axios from 'axios';

interface DecodedToken {
    id: string;
    exp: number;
    // other fields if needed
}

const BASE_URL = 'http://localhost:3002/bids';

export const getBidsById = async (bidId: string): Promise<any> => {
    try {
        const token = localStorage.getItem('jwtToken');

        if (!token) {
            throw new Error('No token found');
        }

        const response = await axios.get(`${BASE_URL}/${bidId}`, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
        });

        return response.data;
    } catch (error) {
        console.error('Error fetching bids:', error);
        throw error;
    }
};

export const getBidsByProductId = async (productId: string): Promise<any> => {
    try {
        const token = localStorage.getItem('jwtToken');

        if (!token) {
            throw new Error('No token found');
        }

        const response = await fetch(`http://localhost:3002/bids/product/${productId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
        });

        if (!response.ok) {
            throw new Error(`Failed to fetch bids: ${response.statusText}`);
        }

        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error fetching bids:', error);
        throw error;
    }
};

export const getBidsByUserId = async (userId: string): Promise<any> => {
    try {
        const token = localStorage.getItem('jwtToken');

        if (!token) {
            throw new Error('No token found');
        }

        const response = await fetch(`http://localhost:3002/bids/user/${userId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
        });

        if (!response.ok) {
            throw new Error(`Failed to fetch bids: ${response.statusText}`);
        }

        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error fetching bids:', error);
        throw error;
    }
};


export const createBid = async (
    productId: string,
    userId: string,
    amount: string
): Promise<any> => {
    try {
        const token = localStorage.getItem('jwtToken');

        if (!token) {
            throw new Error('No token found');
        }

        const response = await axios.post(BASE_URL,
            {
                productId,
                userId,
                amount,
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                },
            }
        );

        return response.data;
    } catch (error) {
        console.error('Error creating bid:', error);
        throw error;
    }
};

export const updateBid = async (
    bidId: string,
    amount?: string
): Promise<any> => {
    try {
        const token = localStorage.getItem('jwtToken');

        if (!token) {
            throw new Error('No token found');
        }

        const response = await axios.patch(`${BASE_URL}/${bidId}`,
            {
                amount,
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                },
            }
        );

        return response.data;
    } catch (error) {
        console.error('Error updating bid:', error);
        throw error;
    }
};
