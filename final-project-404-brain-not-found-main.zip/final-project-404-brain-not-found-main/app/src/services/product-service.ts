import axios from 'axios'; // For HTTP requests
import { Product } from '../models/Products.ts'; // Product model
import {jwtDecode }from 'jwt-decode'; // For decoding JWT tokens

interface DecodedToken {
  id: string;
  exp: number;
  // Add other fields if necessary
}

const BASE_URL = 'http://localhost:3002/products'; // API base URL

const ADMIN_EMAIL = "admin404@gmail.com";
const ADMIN_PASSWORD = "admin@404"; // Admin credentials for fallback

// Fetch all products
export const fetchProducts = async (): Promise<Product[]> => {
  try {
    const token = localStorage.getItem('jwtToken') || `${ADMIN_EMAIL}:${ADMIN_PASSWORD}`;

    const response = await fetch(BASE_URL, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        'email': `${ADMIN_EMAIL}`, // Admin email
        'password': `${ADMIN_PASSWORD}`,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch products');
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching products:', error);
    throw error;
  }
};

// Fetch products by userId
export const fetchProductsByUserID = async (userId: string): Promise<Product[]> => {
  try {
    const token = localStorage.getItem('jwtToken') || `${ADMIN_EMAIL}:${ADMIN_PASSWORD}`;

    const response = await fetch(`${BASE_URL}/user/${userId}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`, 
        'email': `${ADMIN_EMAIL}`, // Admin email
        'password': `${ADMIN_PASSWORD}`,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch products for the given user');
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching products by userId:', error);
    throw error;
  }
};

export const fetchProductByID = async (id: string): Promise<Product> => {
  try {
    const token = localStorage.getItem('jwtToken') || `${ADMIN_EMAIL}:${ADMIN_PASSWORD}`;

    const response = await fetch(`${BASE_URL}/${id}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch product by ID');
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching product by ID:', error);
    throw error;
  }
};

// Add a new product
export const addProduct = async (product: Product): Promise<Product> => {
  try {
    const token = localStorage.getItem('jwtToken') || `${ADMIN_EMAIL}:${ADMIN_PASSWORD}`;

    const response = await fetch(BASE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify(product),
    });

    if (!response.ok) {
      throw new Error('Failed to add product');
    }
    return await response.json();
  } catch (error) {
    console.error('Error adding product:', error);
    throw error;
  }
};

// Update an existing product
export const updateProduct = async (productId: string, product: Product): Promise<Product> => {
  try {
    const token = localStorage.getItem('jwtToken') || `${ADMIN_EMAIL}:${ADMIN_PASSWORD}`;

    const response = await fetch(`${BASE_URL}/${productId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify(product),
    });

    if (!response.ok) {
      throw new Error('Failed to update product');
    }
    return await response.json();
  } catch (error) {
    console.error('Error updating product:', error);
    throw error;
  }
};

// Delete a product
export const deleteProduct = async (productId: string, credentials?: { adminEmail: string; adminPassword: string }) => {
  try {
    const headers: Record<string, string> = {};

    if (credentials?.adminEmail) {
      headers.email = credentials.adminEmail;
      headers.password = credentials.adminPassword;
    } else {
      const token = localStorage.getItem('jwtToken');
      if (!token) {
        throw new Error('No token found. Please log in.');
      }
      headers.Authorization = `Bearer ${token}`;
    }

    const response = await fetch(`http://localhost:3002/products/${productId}`, {
      method: 'DELETE',
      headers,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to delete product: ${errorText}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error deleting product:', error);
    throw error;
  }
};

