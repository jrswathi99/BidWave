import { Bid } from "./Bid.ts";

export interface Auction {
    _id?: string; // Optional for newly created objects
    productId: string; // Reference to the Product ID
    startPrice: number;
    highestBidId?: string; // Optional, as an auction may start without bids
    startTime: Date;
    endTime: Date;
    sellerId: string; // Reference to the User ID of the seller
    status: 'active' | 'closed' | 'pending'; // Enum for auction status
    bids?: Bid[]; // Optional array of bids associated with the auction
    
}
