export interface Product {
    _id?:string;
    itemName: string;
    description?: string;
    category: string;
    minprice: number;
    images: string[];
    userId: string;
    

  }
  
  