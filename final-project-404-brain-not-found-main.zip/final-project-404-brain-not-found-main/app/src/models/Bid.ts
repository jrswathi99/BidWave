export interface Bid {
    _id?: string; // Optional for newly created objects
    productId: string; // ID of the product being bid on
    userId: string; // ID of the user placing the bid
    amount: number; // Amount of the bid
    timestamp?: Date; // Optional, default value would be `Date.now`
}
