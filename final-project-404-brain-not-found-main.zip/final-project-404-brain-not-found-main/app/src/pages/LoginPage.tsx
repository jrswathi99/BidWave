import React from 'react';
import LoginForm from '../components/LoginForm';
import { useNavigate } from 'react-router-dom';
import { Button } from '@mui/material';  // Import Button from MUI

const LoginPage: React.FC<{ onLoginSuccess: () => void }> = ({ onLoginSuccess }) => {
  const navigate = useNavigate(); // Hook to navigate between pages

  return (
    <div>
      {/* Login form component with success callback and API URL */}
      <LoginForm apiUrl="http://localhost:3002" onLoginSuccess={onLoginSuccess} />
    </div>
  );
};

export default LoginPage;
