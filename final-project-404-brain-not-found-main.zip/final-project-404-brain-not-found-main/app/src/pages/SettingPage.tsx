import React from 'react';
import Settings from '../components/settings';

const SettingPage: React.FC = () => {
  return (
    <div>
      <Settings />
    </div>
  );
};

export default SettingPage;