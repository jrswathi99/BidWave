import React from 'react';

const HomePage: React.FC = () => {
  return <h1>Welcome to Home Page</h1>;
};

export default HomePage;
