import React from 'react';
import { TextField, Button, Box, Typography, Grid, Card, CardContent, CardMedia } from '@mui/material';
import { useNavigate } from 'react-router-dom';
 // Import Button from MUI
import MyProducts from '../components/MyProducts.tsx';
import { useTranslation } from 'react-i18next';

const ProductPage: React.FC = () => {
    const { t } = useTranslation(); // Translation hook
    return (
        <Box sx={{ padding: 2 }}>
            <Typography variant="h4" gutterBottom>
                {t('productPage')}
            </Typography> {/* Render the ProductComponent */}
            <MyProducts />
        </Box>
    );
}; 

export default ProductPage;
