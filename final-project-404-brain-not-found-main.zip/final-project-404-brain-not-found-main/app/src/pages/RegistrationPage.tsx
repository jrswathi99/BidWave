import React from 'react';
import RegistrationForm from '../components/RegistrationForm';
import { useNavigate } from 'react-router-dom';
import { Button } from '@mui/material';  // Import Button from MUI

const RegistrationPage: React.FC = () => {
  const navigate = useNavigate();

  // Define the onRegisterSuccess callback to handle successful registration
  const onRegisterSuccess = () => {
    // Navigate to the login page after successful registration
    navigate('/login');
  };

  return (
    <div>
      {/* Pass onRegisterSuccess as a prop to the RegistrationForm */}
      <RegistrationForm apiUrl="http://localhost:3002" onRegisterSuccess={onRegisterSuccess} />
    </div>
  );
};

export default RegistrationPage;
