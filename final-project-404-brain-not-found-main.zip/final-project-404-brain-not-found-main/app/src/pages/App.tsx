import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { ThemeProvider } from '@mui/system'; // Import ThemeProvider
import { lightTheme, darkTheme } from '../themes/theme.ts'; // Import your theme
import LoginPage from "./LoginPage";
import RegistrationPage from "./RegistrationPage";
import HomePage from "../components/homepage";
import Navbar from "../components/Navbar";
import AppRoute from '../routes/AppRouter.tsx'; // Import Routes File
import ProductPage from "./ProductPage.tsx";
import AdminProductPage from "./AdminProductPage.tsx";
import BiddingPage from "../components/biddingpage.tsx";
import MyBidPage from '../components/MyBids.tsx';
import AdminMyBidPage from '../components/AdminMyBids.tsx';
import FormPropsTextFields from "../components/UserProfileupdate.tsx";
import AdminLoginPage from "../components/AdminLoginPage.tsx";
import AdminPage from "../components/AdminPage.tsx";
import SettingPage from './SettingPage.tsx';
import { useTranslation } from 'react-i18next';
import AdminNavbar from "../components/AdminNavBar.tsx";

const App: React.FC = () => {
  const { t } = useTranslation();

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => localStorage.getItem('isAuthenticated') === 'true');
  const [isAdmin, setIsAdmin] = useState<boolean>(false);

  // Add theme state
  const [mode, setMode] = useState<'light' | 'dark'>('light'); // Default theme is light

  // Toggle theme
  const toggleTheme = () => {
    setMode(prevMode => (prevMode === 'light' ? 'dark' : 'light'));
  };

  // Handle user login success
  const handleUserLoginSuccess = () => {
    setIsAuthenticated(true);
    setIsAdmin(false); // Ensure the user is logged in as a regular user
    localStorage.setItem('isAuthenticated', 'true');
  };

  // Handle admin login success
  const handleAdminLoginSuccess = () => {
    setIsAuthenticated(true);
    setIsAdmin(true); // Ensure the user is logged in as an admin
    localStorage.setItem('isAuthenticated', 'true');
  };

  // Handle logout
  const handleLogout = () => {
    setIsAuthenticated(false);
    setIsAdmin(false);
    localStorage.removeItem('isAuthenticated');
  };

  // Automatically check authentication status on mount
  useEffect(() => {
    const savedAuth = localStorage.getItem('isAuthenticated');
    if (savedAuth === 'true') {
      setIsAuthenticated(true);
    }
  }, []);

  return (
    <ThemeProvider theme={mode === 'light' ? lightTheme : darkTheme}> 
    <Router>
      {isAuthenticated && (isAdmin ? <AdminNavbar onLogout={handleLogout} /> : <Navbar onLogout={handleLogout} />)}
      <Routes>
        {!isAuthenticated ? (
          <>
            {/* Public Routes */}
            <Route path="/" element={<Navigate to="/login" />} />
            <Route path="/login" element={<LoginPage onLoginSuccess={handleUserLoginSuccess} />} />
            <Route path="/register" element={<RegistrationPage />} />
            <Route path="/adminlogin" element={<AdminLoginPage onLoginSuccess={handleAdminLoginSuccess} />} />
          </>
        ) : isAdmin ? (
          <>
            {/* Admin-Specific Routes */}
            <Route path="/" element={<Navigate to="/home" />} />
            <Route path="/home" element={<AdminPage/>} />
            <Route path="/myproducts" element={<AdminProductPage />} />
            <Route path="/mybids" element={<AdminMyBidPage />} />
            <Route path="/products/:id" element={<BiddingPage />} />
            <Route path="/profile" element={<FormPropsTextFields />} />
            <Route path="/settings" element={<SettingPage />} />
          </>
        ) : (
          <>
            {/* User-Specific Routes */}
            <Route path="/" element={<Navigate to="/home" />} />
            <Route path="/home" element={<HomePage />} />
            <Route path="/myproducts" element={<ProductPage />} />
            <Route path="/products/:auctionId/:productId" element={<BiddingPage />} />
            <Route path="/profile" element={<FormPropsTextFields />} />
            <Route path="/mybids" element={<MyBidPage />} />
            <Route path="/settings" element={<SettingPage />} />
          </>
        )}
      </Routes>
    </Router>
    </ThemeProvider>
  );
};

export default App;
