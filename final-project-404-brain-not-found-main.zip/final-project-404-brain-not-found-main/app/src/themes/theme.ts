import { createTheme } from '@mui/material/styles';

// Define the light and dark theme variants
const lightTheme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#c8391b',
    },
    background: {
      default: '#fafafa',
      paper: '#fff',
    },
    text: {
      primary: '#000',
      secondary: '#757575',
    },
  },
});

const darkTheme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#1976d2',
    },
    background: {
      default: '#121212',
      paper: '#1c1c1c',
    },
    text: {
      primary: '#fff',
      secondary: '#bdbdbd',
    },
  },
});

export { lightTheme, darkTheme };
