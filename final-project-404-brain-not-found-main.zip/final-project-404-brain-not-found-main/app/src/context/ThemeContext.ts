import React, { createContext, ReactNode, useState, useMemo, FC } from 'react';
import { ThemeProvider as MuiThemeProvider, CssBaseline } from '@mui/material';
import { darkTheme, lightTheme } from './themes'; // Assuming you have darkTheme and lightTheme defined

// Create a context for theme (optional, if you want to provide a way to toggle theme)
export const ThemeContext = createContext({
  toggleTheme: () => {},  // Placeholder for toggle function
});

interface ThemeContextProviderProps {
  children: ReactNode; // Type the children prop as ReactNode
}

const ThemeContextProvider: FC<ThemeContextProviderProps> = ({ children }) => {
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false); // useState with boolean type

  // Use useMemo to avoid recalculating theme unless isDarkMode changes
  const theme = useMemo(() => (isDarkMode ? darkTheme : lightTheme), [isDarkMode]);

  // Function to toggle the theme
  const toggleTheme = () => {
    setIsDarkMode((prevMode) => !prevMode);
  };

  return (
    <ThemeContext.Provider value={{ toggleTheme }}>
      <MuiThemeProvider theme={theme}>
        <CssBaseline />
        {children} {/* Render the children prop */}
      </MuiThemeProvider>
    </ThemeContext.Provider>
  );
};

export default ThemeContextProvider;
