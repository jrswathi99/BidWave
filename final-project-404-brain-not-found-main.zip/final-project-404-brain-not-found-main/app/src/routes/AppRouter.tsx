import React from 'react';
import {  Routes, Route } from 'react-router-dom';
import Homepage from '../components/homepage';
import UserProfileupdate from '../components/UserProfileupdate.tsx'; // User Profile Edit
import ProductPage from '../components/MyProducts.tsx';
// import  from '../pages/App.tsx'; // Example Home component

const AppRoute: React.FC = () => {
    return (
      <Routes>
        {/* <Route path="/" element={<App />} /> */}
        <Route path="/home" element={<Homepage />} />
        <Route path="/profile" element={<UserProfileupdate />} />
        <Route path="/myproducts" element={<ProductPage />} />
      </Routes>
    );
  };

export default AppRoute;
