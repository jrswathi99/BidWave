import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { addProduct, updateProduct, deleteProduct, fetchProductsByUserID } from '../services/product-service';
import { Product } from '../models/Products';

interface ProductState {
  products: Product[];
  loading: boolean;
  error: string | null;
}

const initialState: ProductState = {
  products: [],
  loading: false,
  error: null,
};

// Async thunks for product operations
export const fetchProductsByUser = createAsyncThunk(
  'products/fetchByUser',
  async (userId: string, { rejectWithValue }) => {
    try {
      return await fetchProductsByUserID(userId);
    } catch (error) {
      return rejectWithValue((error as Error).message);
  }}
);

export const addNewProduct = createAsyncThunk(
  'products/add',
  async (product: Product, { rejectWithValue }) => {
    try {
      return await addProduct(product);
    } catch (error) {
      return rejectWithValue((error as Error).message);
  }}
);

export const updateExistingProduct = createAsyncThunk(
  'products/update',
  async ({ productId, product, token }: { productId: string, product: Product, token: string }, { rejectWithValue }) => {
    try {
      return await updateProduct(productId, product, token);
    } catch (error) {
      return rejectWithValue((error as Error).message);
    }
  }
);

export const deleteExistingProduct = createAsyncThunk(
  'products/delete',
  async ({ productId, token, adminEmail, adminPassword }: { productId: string, token: string, adminEmail?: string, adminPassword?: string }, { rejectWithValue }) => {
    try {
      await deleteProduct(productId, token, adminEmail, adminPassword);
      return productId;
    } catch (error ) {
      return rejectWithValue((error as Error).message);
    }
  }
);

const productSlice = createSlice({
  name: 'products',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchProductsByUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchProductsByUser.fulfilled, (state, action) => {
        state.loading = false;
        state.products = action.payload;
      })
      .addCase(fetchProductsByUser.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(addNewProduct.fulfilled, (state, action) => {
        state.products.push(action.payload);
      })
      .addCase(updateExistingProduct.fulfilled, (state, action) => {
        const index = state.products.findIndex(product => product._id === action.payload._id);
        if (index !== -1) {
          state.products[index] = action.payload;
        }
      })
      .addCase(deleteExistingProduct.fulfilled, (state, action) => {
        state.products = state.products.filter(product => product._id !== action.payload);
      });
  },
});

export default productSlice.reducer;