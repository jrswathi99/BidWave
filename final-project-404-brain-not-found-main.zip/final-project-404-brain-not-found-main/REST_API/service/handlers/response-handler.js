/**
 * Sends a successful response with the provided data.
 * @param {Object} data - The data to be included in the response.
 * @param {Object} response - The HTTP response object.
 */
export const setSuccess = (data, response) => {
    if (response.status(200) || response.status(201)) { // Check if the response status is 200 or 201
        response.json(data); // Send the data as a JSON response
    }
};

/**
 * Sends an error response based on the status code and error details.
 * @param {Object} error - The error object containing the message.
 * @param {Object} response - The HTTP response object.
 */
export const setError = (error, response) => {
    if (response.status(500)) { // Handle internal server error
        response.json({
            code: 500,
            message: error.message
        });
    } else if (response.status(400)) { // Handle bad request error
        response.json({
            code: 400,
            message: error.message
        });
    } else if (response.status(404)) { // Handle not found error
        response.json({
            code: 404,
            message: error.message
        });
    } else if (response.status(401)) { // Handle unauthorized error
        response.json({
            code: 401,
            message: error.message
        });
    }
};
