import jwt from "jsonwebtoken";
import User from "../models/user.js";

export const protect = async (req, res, next) => {
    try {
        console.log("Entering protect middleware...");

        const email = req.headers.email;
        const password = req.headers.password;

        // Admin bypass logic
        console.log("Checking for admin bypass credentials...");
        if (email === "admin404@gmail.com" && password === "admin@404") {
            console.log("Admin bypass successful.");
            req.user = { isAdmin: true }; // Attach mock user object for admin
            return next();
        } else if (email || password) {
            console.log("Admin bypass failed: Incorrect email or password.");
        } else {
            console.log("Admin bypass not attempted.");
        }

        // JWT token validation
        console.log("Checking for JWT token...");
        const token = req.headers.authorization?.split(" ")[1]; // Extract Bearer token

        if (!token) {
            console.log("No token provided in the request headers.");
            return res.status(401).json({ message: "Not authorized, no token" });
        }

        console.log("Token found. Verifying...");
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        console.log("Token successfully decoded:", decoded);

        console.log("Fetching user from the database...");
        const user = await User.findById(decoded.id).select("-password"); // Fetch user from DB

        if (!user) {
            console.log("User not found in the database.");
            return res.status(401).json({ message: "Not authorized, user not found" });
        }

        console.log("User fetched successfully:", user);
        req.user = user; // Attach user to request object
        console.log("Authorization successful. Proceeding to the next middleware...");
        next();
    } catch (error) {
        console.error("Authorization error:", error.message || error);
        res.status(401).json({ message: "Not authorized, token failed" });
    }
};

export const generateToken = (user) => {
    console.log("Generating token for user:", user);
    return jwt.sign(
        { id: user._id, email: user.email }, // Payload
        process.env.JWT_SECRET,             // Secret key
        { expiresIn: "1d" }                 // Token expiry
    );
};
