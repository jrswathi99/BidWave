import { typographyClasses } from "@mui/material";
import mongoose from "mongoose";

const ProductSchema = new mongoose.Schema({
   
    itemName: {
        required: true,
        type: String,
    },
    description: {
        type: String,
    },
    category: {
        required : true,
        type: String,
    },
    minprice:{
        required: true,
        type: Number,
    },
     
    images: {
        
        type: [String],
        default: [],
    },

    userId: {
        type: mongoose.Schema.Types.ObjectId, // Refers to the ObjectId of a user
        ref: "User", // Reference to the User model
        required: true, // Ensure that a userId is always provided
    },
});

const ProductModel = mongoose.model("Product", ProductSchema);
export default ProductModel;
