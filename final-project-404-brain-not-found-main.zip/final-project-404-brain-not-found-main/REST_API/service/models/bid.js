import mongoose from "mongoose";

/**
 * Defines the schema for the Bid collection in the database.
 */
const BidSchema = new mongoose.Schema({
    productId: {
        type: String, // The ID of the product being bid on
        required: true, // Indicates that this field is mandatory
    },
    userId: {
        type: String, // The ID of the user placing the bid
        required: true, // Indicates that this field is mandatory
    },
    amount: {
        type: Number, // The amount of the bid
        required: true, // Indicates that this field is mandatory
    },
    timestamp: {
        type: Date, // The time when the bid was placed
        required: true, // Indicates that this field is mandatory
        default: Date.now, // Sets the default value to the current date and time
    },
});

/**
 * Creates a Mongoose model for the Bid collection using the defined schema.
 */
const BidModel = mongoose.model('Bid', BidSchema);

export default BidModel;
