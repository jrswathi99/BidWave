import mongoose from "mongoose";

const auctionSchema = new mongoose.Schema({
    
    productId: {
        required: true,
        type: mongoose.Schema.Types.ObjectId,
        ref: "Product", 
    },
    startPrice: {
        type: Number,
        required: true
    },
    highestBidId: {
        type: mongoose.Schema.Types.ObjectId, // Refers to the ObjectId of a user
        ref: "Bid", // Reference to the User model
    },
    startTime: {
        type: Date,
        required: true,
        default: Date.now,
    },
    endTime: {
        type: Date,
        required: true
    },
    sellerId: {
        required: true,
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true
    },
    endTime: {
        type: Date,
        required: true
    },
    sellerId: {
        type: mongoose.Schema.Types.ObjectId, // Refers to the ObjectId of a user
        ref: "User", // Reference to the User model
        required: true
    },
    status: {
        type: String,
        enum: ['active', 'closed', 'pending'],
        default: 'pending'
    }
});

const AuctionModel = mongoose.model('Auction', auctionSchema);
export default AuctionModel;
