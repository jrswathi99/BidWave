import mongoose from "mongoose";


const NoficationSchema = new mongoose.Schema({
    userId: {
        required: true,
        type: String
    },
    message:{
        required: true,
        type: String,
    },
    notificationType:{
        required: true,
        type: String,
        enum: ['Info','Warning','Error']
    },
    seen: Boolean
});

const NotificationModel = mongoose.model('Notification',NoficationSchema);
export default NotificationModel;