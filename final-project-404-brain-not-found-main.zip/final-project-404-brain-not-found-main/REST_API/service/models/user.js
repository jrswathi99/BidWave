import mongoose from "mongoose";
import bcrypt from 'bcryptjs';


const UserSchema = new mongoose.Schema({
    username: {
        required: true,
        type: String
    },
    password: {
        required: true,
        type: String
    },
    email:{
        required: true,
        type: String,
        match: /.+\@.+\..+/,
    },
    registeredOn:{
        type: String,
        default: Date.now,
    },
    gender: String,
    age: String
});

// Hash password before saving
UserSchema.pre("save", async function (next) {
    if (!this.isModified("password")) return next();
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
});

UserSchema.pre("findOneAndUpdate", async function (next) {
    const update = this.getUpdate();

    // Check if password is being updated
    if (update.password) {
        const salt = await bcrypt.genSalt(10);
        update.password = await bcrypt.hash(update.password, salt);
    }

    next();
});

UserSchema.methods.comparePassword = async function (candidatePassword) {
    return bcrypt.compare(candidatePassword, this.password);
};



UserSchema.index({ email: 1 }, { unique: true });
const UserModel = mongoose.model('User',UserSchema);
export default UserModel;