import { response } from "express";
import * as auctionService from "./../services/auction-services.js";
import { setError, setSuccess } from "./../handlers/response-handler.js";

// Handler for creating a new auction
export const postAuction = async (request, response) => {
    try {
        const newAuction = { ...request.body };
        const auction = await auctionService.createAuction(newAuction);
        setSuccess(auction, response, 201); // using 201 for creation success

    } catch (error) {
        // console.error("Error in postAuction:", error);
        setError(error, response);
    }
}

// Handler for getting all auctions
export const getAllAuctions = async (request, response) => {
    try {
        const auctions = await auctionService.getAllAuctions();
        setSuccess(auctions, response);
    } catch (error) {
        setError(error, response);
    }
}

export const getAuctionByProductId = async (request, response) => {
    try {
        const productId = request.params.id; // Extract product ID from the request parameters
        const auction = await auctionService.getAuctionByProductId(productId); // Fetch bids by product ID

        if (!auction) {
            setError(error, response); // Send an error response if no bids are found
            return;
        }
        setSuccess(auction, response); // Send a success response with the fetched bids
    } catch (error) {
        setError(error, response); // Send an error response if any error occurs
    }
};


// Handler for getting an auction by ID
export const getAuctionById = async (request, response) => {
    try {
        const auction = await auctionService.getAuctionById(request.params.auctionId);
        if (!auction) {
            setError({ message: "Auction not found" }, response, 404);
        } else {
            setSuccess(auction, response);
        }
    } catch (error) {
        setError(error, response);
    }
}

// Handler for updating an auction
export const updateAuction = async (request, response) => {
    try {
        const updatedAuction = await auctionService.updateAuction(request.params.auctionId, request.body);
        if (!updatedAuction) {
            setError({ message: "Auction not found" }, response, 404);
        } else {
            setSuccess(updatedAuction, response);
        }
    } catch (error) {
        setError(error, response);
    }
}

// Handler for deleting an auction
export const deleteAuction = async (request, response) => {
    try {
        const isDeleted = await auctionService.deleteAuction(request.params.auctionId);
        if (!isDeleted) {
            setError({ code: 404, message: "User not found" }, response);
            return;
        }

        setSuccess({ message: "User successfully deleted" }, response);
    } catch (error) {
        setError(error, response);
    }
}
