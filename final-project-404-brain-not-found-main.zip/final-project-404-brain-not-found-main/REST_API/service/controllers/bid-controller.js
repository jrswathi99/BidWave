import { response } from "express";
import * as BidService from "./../services/bid-services.js";
import { setError, setSuccess } from "./../handlers/response-handler.js";

/**
 * Handles the creation of a new bid.
 * @param {Object} request - The HTTP request object, containing the bid details in the body.
 * @param {Object} response - The HTTP response object.
 */
export const post = async (request, response) => {
    try {
        const newBid = { ...request.body }; // Extract bid details from the request body
        const bid = await BidService.save(newBid); // Save the bid using the BidService
        setSuccess(bid, response); // Send a success response with the created bid
    } catch (error) {
        setError(error, response); // Send an error response if any error occurs
    }
};

/**
 * Handles fetching a bid by its ID.
 * @param {Object} request - The HTTP request object, containing the bid ID in the params.
 * @param {Object} response - The HTTP response object.
 */
export const get = async (request, response) => {
    try {
        const bidId = request.params.id; // Extract bid ID from the request parameters
        const bid = await BidService.getById(bidId); // Fetch the bid by ID

        if (!bid) {
            setError(error, response); // Send an error response if bid is not found
            return;
        }
        setSuccess(bid, response); // Send a success response with the fetched bid
    } catch (error) {
        setError(error, response); // Send an error response if any error occurs
    }
};

/**
 * Handles fetching bids by product ID.
 * @param {Object} request - The HTTP request object, containing the product ID in the params.
 * @param {Object} response - The HTTP response object.
 */
export const getByProductId = async (request, response) => {
    try {
        const productId = request.params.id; // Extract product ID from the request parameters
        const bids = await BidService.getByProductId(productId); // Fetch bids by product ID

        if (!bids) {
            setError(error, response); // Send an error response if no bids are found
            return;
        }
        setSuccess(bids, response); // Send a success response with the fetched bids
    } catch (error) {
        setError(error, response); // Send an error response if any error occurs
    }
};

export const getByUserId = async (request, response) => {
    try {
        const userId = request.params.id; // Extract product ID from the request parameters
        const bids = await BidService.getByUserId(userId); // Fetch bids by product ID

        if (!bids) {
            setError(error, response); // Send an error response if no bids are found
            return;
        }
        setSuccess(bids, response); // Send a success response with the fetched bids
    } catch (error) {
        setError(error, response); // Send an error response if any error occurs
    }
};

/**
 * Handles updating a bid by its ID.
 * @param {Object} request - The HTTP request object, containing the bid ID in the params and updates in the body.
 * @param {Object} response - The HTTP response object.
 */
export const patch = async (request, response) => {
    try {
        const bidId = request.params.id; // Extract bid ID from the request parameters
        const updates = { ...request.body }; // Extract updates from the request body

        const updatedBid = await BidService.patchById(bidId, updates); // Update the bid by ID

        if (!updatedBid) {
            setError(error, response); // Send an error response if bid is not found or not updated
            return;
        }

        setSuccess(updatedBid, response); // Send a success response with the updated bid
    } catch (error) {
        setError(error, response); // Send an error response if any error occurs
    }
};

/**
 * Handles deleting a bid by its ID.
 * @param {Object} request - The HTTP request object, containing the bid ID in the params.
 * @param {Object} response - The HTTP response object.
 */
export const remove = async (request, response) => {
    try {
        const bidId = request.params.id; // Extract bid ID from the request parameters
        const isDeleted = await BidService.deleteById(bidId); // Delete the bid by ID

        if (!isDeleted) {
            setError(error, response); // Send an error response if bid is not found or not deleted
            return;
        }

        setSuccess(null, response); // Send a success response with no content
    } catch (error) {
        setError(error, response); // Send an error response if any error occurs
    }
};
