import * as productService from "../services/product-service.js";
import { setSuccess, setError } from "../handlers/response-handler.js";
import mongoose from "mongoose";

export const getAllProducts = async (req, res) => {
    try {
        const products = await productService.getAll();
        res.status(200);
        setSuccess(products, res);
    } catch (err) {
        res.status(500);
        setError(err, res);
    }
};

export const getProductById = async (req, res) => {
    try {
        const { productId } = req.params;
        const product = await productService.getById(productId);
        if (!product) {
            res.status(404);
            return setError(new Error("Product not found"), res);
        }
        res.status(200);
        setSuccess(product, res);
    } catch (err) {
        res.status(500);
        setError(err, res);
    }
};
export const getProductByUserId = async (req, res) => {
    try {
        const { userId } = req.params;
        console.log(`Received user ID: ${userId}`);

        // Validate the user ID
        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ message: 'Invalid user ID' });
        }

        // Fetch the product
        const product = await productService.getByUserId(userId);

        // Handle case where product is not found
        if (!product) {
            return res.status(404).json({ message: "Product not found" });
        }

        // Respond with the product
        return res.status(200).json(product);
    } catch (err) {
        console.error('Database query error:', err.message);

        // Handle unexpected errors
        return res.status(500).json({ message: 'Internal Server Error', error: err.message });
    }
};


export const createProduct = async (req, res) => {
    try {
        const newProduct = req.body;
        const createdProduct = await productService.save(newProduct);
        res.status(201);
        setSuccess(createdProduct, res);
    } catch (err) {
        res.status(400);
        setError(err, res);
    }
};

export const updateProductById = async (req, res) => {
    try {
        const { productId } = req.params;
        const updates = req.body;
        const updatedProduct = await productService.updateById(productId, updates);
        if (!updatedProduct) {
            res.status(404);
            return setError(new Error("Product not found"), res);
        }
        res.status(200);
        setSuccess(updatedProduct, res);
    } catch (err) {
        res.status(400);
        setError(err, res);
    }
};

export const patchProductById = async (req, res) => {
    try {
        const { productId } = req.params;
        const updates = req.body;
        const updatedProduct = await productService.patchById(productId, updates);
        if (!updatedProduct) {
            res.status(404);
            return setError(new Error("Product not found"), res);
        }
        res.status(200);
        setSuccess(updatedProduct, res);
    } catch (err) {
        res.status(400);
        setError(err, res);
    }
};

export const deleteProductById = async (req, res) => {
    try {
        const { productId } = req.params;
        const deleted = await productService.deleteById(productId);
        if (!deleted) {
            res.status(404);
            return setError(new Error("Product not found"), res);
        }
        res.status(204);
        setSuccess(null, res);
    } catch (err) {
        res.status(500);
        setError(err, res);
    }
};

export const getProductsByUser = async (req, res) => {
    const { userId } = req.params;
    try {
        const products = await productService.getByUserId(userId);
        res.status(200).json(products);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
