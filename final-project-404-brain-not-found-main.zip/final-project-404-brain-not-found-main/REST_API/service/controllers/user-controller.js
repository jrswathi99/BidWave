import * as UserService from "./../services/user-service.js";
import { setError, setSuccess } from "./../handlers/response-handler.js";
import { generateToken } from "../handlers/jwt-handler.js"; // Importing generateToken
import bcrypt from "bcryptjs";
import User from "../models/user.js";

// Register user
export const register = async (req, res) => {
  try {
    const { username, email, password, gender, age } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "Email already in use" });
    }

    // Create new user
    const newUser = new User({
      username,
      email,
      password,
      gender,
      age,
    });

    await UserService.save(newUser);

    res.status(201).json({ message: "User registered successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error registering user", error });
  }
};

// Login user
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Check if user exists
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Compare passwords
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    // Generate JWT
    const token = generateToken(user);

    res.status(200).json({ message: "Login successful", token });
  } catch (error) {
    res.status(500).json({ message: "Error logging in", error });
  }
};

// Create a new user
export const post = async (request, response) => {
  try {
    const newUser = { ...request.body };
    const user = await UserService.save(newUser);

    setSuccess(user, response);
  } catch (error) {
    setError(error, response);
  }
};

// Get all users
export const getAll = async (req, res) => {
  try {
    // Hardcoded admin credentials
    const adminEmail = "admin404@gmail.com"; // Replace with your admin's email
    const adminPassword = "admin@404"; // Replace with your admin's password

    // Check if the request contains admin credentials
    const { email, password } = req.headers;

    if (email === adminEmail && password === adminPassword) {
      // Admin bypass - fetch all users without requiring JWT
      const users = await UserService.getAllUsers();
      return setSuccess(users, res);
    }

    // If not admin, validate JWT (handled by middleware)
    const users = await UserService.getAllUsers();
    setSuccess(users, res);
  } catch (error) {
    setError(error, res);
  }
};



// Get a user by ID
export const get = async (request, response) => {
  try {
    const userId = request.params.id; // Extract user ID from request parameters
    const user = await UserService.getById(userId);

    if (!user) {
      setError({ code: 404, message: "User not found" }, response);
      return;
    }
    setSuccess(user, response);
  } catch (error) {
    setError(error, response);
  }
};

// Get a user by email
export const getByEmail = async (request, response) => {
  try {
    const userEmail = request.params.email; // Extract email from request parameters
    const user = await UserService.getByEmail(userEmail);

    if (!user) {
      return response.status(404).json({
        success: false,
        message: "User not found with this email",
      });
    }

    return response.status(200).json({
      success: true,
      data: user,
    });
  } catch (error) {
    console.error(error);
    return response.status(500).json({
      success: false,
      message: "An error occurred while fetching the user.",
    });
  }
};

// Update a user by ID
export const update = async (request, response) => {
  try {
    const userId = request.params.id;
    const updates = { ...request.body };
    const updatedUser = await UserService.updateById(userId, updates);

    if (!updatedUser) {
      setError({ code: 404, message: "User not found" }, response);
      return;
    }
    setSuccess(updatedUser, response);
  } catch (error) {
    setError(error, response);
  }
};

// Partially update a user by ID
export const patch = async (request, response) => {
  try {
    const userId = request.params.id;
    const updates = { ...request.body };

    const updatedUser = await UserService.patchById(userId, updates);

    if (!updatedUser) {
      setError({ code: 404, message: "User not found" }, response);
      return;
    }

    setSuccess(updatedUser, response);
  } catch (error) {
    setError(error, response);
  }
};

// Delete a user by ID
export const remove = async (request, response) => {
  try {
    // Hardcoded admin credentials
    const adminEmail = "admin404@gmail.com"; // Replace with your admin's email
    const adminPassword = "admin@404"; // Replace with your admin's password

    // Check if the request contains admin credentials
    const { email, password } = request.headers;

    if (email === adminEmail && password === adminPassword) {
      // Admin bypass - delete user without requiring JWT
      const userId = request.params.id;
      const isDeleted = await UserService.deleteById(userId);

      if (!isDeleted) {
        return setError({ code: 404, message: "User not found" }, response);
      }

      return setSuccess({ message: "User successfully deleted" }, response);
    }

    // If not admin, validate JWT (handled by middleware)
    const userId = request.params.id;
    const isDeleted = await UserService.deleteById(userId);

    if (!isDeleted) {
      return setError({ code: 404, message: "User not found" }, response);
    }

    setSuccess({ message: "User successfully deleted" }, response);
  } catch (error) {
    setError(error, response);
  }
};

