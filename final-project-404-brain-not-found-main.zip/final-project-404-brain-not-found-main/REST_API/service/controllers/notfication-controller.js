import { response } from "express";
import * as NotificationService from "./../services/notification-service.js";
import { setError, setSuccess } from "./../handlers/response-handler.js";


export const post = async (request,response) => {
    try{
        const newNotification={...request.body};
        console.log(newNotification);
        const notification= await NotificationService.save(newNotification);
        
        setSuccess(notification, response);
    } catch(error){
        setError(error, response);
       
}
}


export const getAll = async (req, res) => {
    try {
        const notifications = await NotificationService.getAllnotifications();
        setSuccess(notifications, res);
    } catch (error) {
        setError(error, res);
    }
};

// Retrieve a user by ID
export const get = async (request, response) => {
    try {
        const notificationId = request.params.id; // Extract user ID from request parameters
        const notification = await NotificationService.getById(notificationId);

        if (!notification) {
            setError(error, response);
            return;
        }
        setSuccess(notification, response);
    } catch (error) {
        setError(error, response);
    }
};

export const getByUserId = async (request, response) => {
    try {
        const userId = request.params.id; 
        const notification = await NotificationService.getByUserId(userId);

        if (!notification) {
            setError(error, response);
            return;
        }
        setSuccess(notification, response);
    } catch (error) {
        setError(error, response);
    }
};
// Update a user by ID
export const update = async (request, response) => {
    try {
        const notificationId = request.params.id; // Extract user ID from request parameters
        const updates = { ...request.body }; // Extract updates from request body
        const updatedNotification = await NotificationService.updateById(notificationId, updates);

        if (!updatedNotification) {
            setError(error, response);
            return;
        }
        setSuccess(updatedNotification, response);
    } catch (error) {
        setError(error, response);
    }
};


export const patch = async (request, response) => {
    try {
        const notificationId = request.params.id; // Extract user ID from request parameters
        const updates = { ...request.body }; // Extract partial updates from request body

        // Find the user by ID and apply the updates
        const updatedNotification = await NotificationService.patchById(notificationId, updates);

        if (!updatedNotification) {
            setError(error, response);
            return;
        }

        setSuccess(updatedNotification, response);
    } catch (error) {
        setError(error, response);
    }
};

// Delete a user by ID
export const remove = async (request, response) => {
    try {
        const notificationId = request.params.id; // Extract user ID from request parameters
        const isDeleted = await NotificationService.deleteById(notificationId);

        if (!isDeleted) {
            setError({ code: 404, message: "Notification not found" }, response);
            return;
        }

        setSuccess({ message: "Notification successfully deleted" }, response);
    } catch (error) {
        setError(error, response);
    }
};