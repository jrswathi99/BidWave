import Bid from "./../models/bid.js";

/**
 * Saves a new bid to the database.
 * @param {Object} newBid - The bid object to be saved.
 * @returns {Promise<Object>} - The saved bid document.
 */
export const save = async (newBid) => {
    const bid = new Bid(newBid); // Create a new bid instance
    return bid.save(); // Save the bid to the database
};

/**
 * Retrieves a bid by its ID.
 * @param {String} id - The ID of the bid to retrieve.
 * @returns {Promise<Object|null>} - The bid document or null if not found.
 */
export const getById = async (id) => {
    return Bid.findById(id); // Find the bid by its ID
};

/**
 * Retrieves all bids associated with a specific product ID.
 * @param {String} id - The product ID.
 * @returns {Promise<Array>} - An array of bids associated with the product.
 */
export const getByProductId = async (id) => {
    return Bid.find({ productId: id }); // Find bids with the specified product ID
};

export const getByUserId = async (id) => {
    return Bid.find({ userId: id }); // Find bids with the specified product ID
};

/**
 * Updates a bid by its ID with the given updates.
 * @param {String} id - The ID of the bid to update.
 * @param {Object} updates - The updates to apply to the bid.
 * @returns {Promise<Object|null>} - The updated bid document or null if not found.
 */
export const patchById = async (id, updates) => {
    return Bid.findByIdAndUpdate(id, updates, { new: true, runValidators: true }); 
    // Update the bid and return the updated document
};

/**
 * Deletes a bid by its ID.
 * @param {String} id - The ID of the bid to delete.
 * @returns {Promise<Boolean>} - True if the bid was deleted, false otherwise.
 */
export const deleteById = async (id) => {
    const result = await Bid.findByIdAndDelete(id); // Delete the bid by its ID
    return result !== null; // Return true if a bid was deleted, false otherwise
};
