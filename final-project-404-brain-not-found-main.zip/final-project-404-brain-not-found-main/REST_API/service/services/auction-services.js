import Auction from "./../models/auction.js";

// Service to save a new auction
export const createAuction = async (newAuction) => {
    const auction = new Auction(newAuction);
    return auction.save();
};

// Service to retrieve all auctions
export const getAllAuctions = async () => {
    return await Auction.find({});
}

// Service to retrieve a single auction by ID
export const getAuctionById = async (auctionId) => {
    return await Auction.findById(auctionId);
}

// Service to update an auction
export const updateAuction = async (auctionId, updateData) => {
    return await Auction.findByIdAndUpdate(auctionId, updateData, { new: true });
}

// Service to delete an auction
export const deleteAuction = async (auctionId) => {
    return await Auction.findByIdAndDelete(auctionId);
}

export const getAuctionByProductId = async (id) => {
    return Auction.find({ productId: id }); 
};
