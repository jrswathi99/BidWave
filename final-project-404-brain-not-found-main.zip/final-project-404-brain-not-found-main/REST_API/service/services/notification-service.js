import Notification from "./../models/notification.js"

export const save = async (newNotification) => {
    const notification= new Notification(newNotification);
    return notification.save();
}

export const getAllnotifications= async () => {
    return Notification.find();
};

export const getById = async (id) => {
    return Notification.findById(id); 
};

export const getByUserId = async (id) => {
    return Notification.find({ userId: id });
};

export const updateById = async (id, updates) => {
    return Notification.findByIdAndUpdate(id, updates, { new: true }); 
};

export const patchById = async (id, updates) => {
    return Notification.findByIdAndUpdate(id, updates, { new: true, runValidators: true });
  
};

export const deleteById = async (id) => {
    const result = await Notification.findByIdAndDelete(id); 
    return result !== null; 
};