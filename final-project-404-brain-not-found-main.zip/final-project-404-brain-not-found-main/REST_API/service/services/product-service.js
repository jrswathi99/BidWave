import Product from "../models/product.js";
import mongoose from "mongoose";

// Save a new product
export const save = async (newProduct) => {
    const product = new Product(newProduct);
    return product.save();
};

// Get a product by ID
export const getById = async (id) => {
    return Product.findById(id);
};

// Update a product by ID
export const updateById = async (id, updates) => {
    return Product.findByIdAndUpdate(id, updates, { new: true });
};

// Patch a product by ID (partial updates)
export const patchById = async (id, updates) => {
    return Product.findByIdAndUpdate(id, updates, { new: true, runValidators: true });
  
};

// Delete a product by ID
export const deleteById = async (id) => {
    const result = await Product.findByIdAndDelete(id);
    return result !== null; // Returns true if the product was deleted, false otherwise
};

// Get all products (Optional: You can add filters or pagination here)
export const getAll = async (filters = {}) => {
    return Product.find(filters);
};

// Get all products created by a specific user
export const getByUserId = async (userId) => {
    // console.log(`Querying products for userId: ${userId}`);
    // return Product.find({ userId: userId});
    const { ObjectId } = mongoose.Types; // Ensure ObjectId is correctly referenced here

    return Product.find({ userId: userId });
};
