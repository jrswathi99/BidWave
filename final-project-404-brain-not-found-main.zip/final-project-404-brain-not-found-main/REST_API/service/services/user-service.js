import User from "./../models/user.js"

export const save = async (newUser) => {
    const user= new User(newUser);
    return user.save();
}

export const getAllUsers = async () => {
    return User.find(); // Fetches all users from the database
};

export const getById = async (id) => {
    return User.findById(id); 
};


export const updateById = async (id, updates) => {
    return User.findByIdAndUpdate(id, updates, { new: true }); 
};

export const patchById = async (id, updates) => {
    return User.findByIdAndUpdate(id, updates, { new: true, runValidators: true });
    // The { new: true } option ensures the updated document is returned.
    // The runValidators option ensures that the updates follow the schema's validation rules.
};

export const deleteById = async (id) => {
    const result = await User.findByIdAndDelete(id); 
    return result !== null; // Returns true if the user was deleted, false otherwise
};

export const getByEmail = async (email) => {
    return User.findOne({ email }); // Fetches the first user matching the provided email
};
