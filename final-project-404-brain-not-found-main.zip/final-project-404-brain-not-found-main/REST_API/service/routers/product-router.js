import express from "express";
import { protect } from '../handlers/jwt-handler.js';
import * as productController from "./../controllers/product-controller.js"

const router = express.Router();
router.get('/', protect, productController.getAllProducts);
router.get('/user/:userId', protect, productController.getProductByUserId);
router.get('/:productId', protect, productController.getProductById);
router.post('', protect, productController.createProduct);
router.put('/:productId', protect, productController.updateProductById);
router.patch('/:productId', protect, productController.patchProductById);
router.delete('/:productId', protect, productController.deleteProductById);




export default router;


