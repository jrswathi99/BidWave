import express from 'express';
import { protect } from '../handlers/jwt-handler.js'; // Import the JWT middleware
import * as userController from "./../controllers/user-controller.js"

const router = express.Router();

// Public routes (No authentication required)
router.post('/register', userController.register); // User registration
router.post('/login', userController.login);    
   // User login

// Protected routes (Require JWT authentication)
router.post('/', protect, userController.post);       // Create a new user
router.get('/', protect, userController.getAll);      // Get all users
router.get('/:id', protect, userController.get);      // Get user by ID
router.get('/email/:email', protect, userController.getByEmail); // Get user by email
router.put('/:id', protect, userController.update);   // Update user by ID
router.patch('/:id', protect, userController.patch);  // Partial update
router.delete('/:id', protect, userController.remove); // Delete user by ID

export default router;
