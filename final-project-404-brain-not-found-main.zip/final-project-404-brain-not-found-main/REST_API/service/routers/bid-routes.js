import express from "express";
import * as bidController from "./../controllers/bid-controller.js";
import { protect } from '../handlers/jwt-handler.js'; // Import the JWT middleware

const router = express.Router();

/**
 * Route to create a new bid.
 * POST /
 * Calls the `post` method in the bid controller.
 */
router.route('/',protect).post(bidController.post);

/**
 * Route to get a bid by its ID.
 * GET /:id
 * Calls the `get` method in the bid controller.
 */
router.route('/:id',protect).get(bidController.get);

/**
 * Route to get all bids associated with a specific product ID.
 * GET /product/:id
 * Calls the `getByProductId` method in the bid controller.
 */
router.route('/product/:id',protect).get(bidController.getByProductId);

router.route('/user/:id',protect).get(bidController.getByUserId);
/**
 * Route to update a bid by its ID.
 * PATCH /:id
 * Calls the `patch` method in the bid controller.
 */
router.route('/:id',protect).patch(bidController.patch);

/**
 * Route to delete a bid by its ID.
 * DELETE /:id
 * Calls the `remove` method in the bid controller.
 */
router.route('/:id',protect).delete(bidController.remove);

export default router;
