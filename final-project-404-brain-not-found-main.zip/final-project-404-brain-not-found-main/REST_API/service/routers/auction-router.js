import express from "express";
import * as auctionController from "../controllers/auction-controller.js";
import { protect } from '../handlers/jwt-handler.js'; // Import the JWT middleware

const router = express.Router();

// Route for handling creation and retrieval of all auctions
router.route('/',protect).post(auctionController.postAuction);
router.route('/',protect).get(auctionController.getAllAuctions);
router.route('/product/:id',protect).get(auctionController.getAuctionByProductId);

// Route for handling single auction operations (get, update, delete)
router.route('/:auctionId',protect)
    .get(auctionController.getAuctionById)
    .patch(auctionController.updateAuction)
    .delete(auctionController.deleteAuction);

export default router;
