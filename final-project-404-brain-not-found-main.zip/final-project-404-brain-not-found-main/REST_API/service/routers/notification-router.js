import express from "express";
import * as NotificationController from "./../controllers/notfication-controller.js"
import { protect } from '../handlers/jwt-handler.js'; // Import the JWT middleware

const router= express.Router();

router.route('/',protect).post(NotificationController.post);
router.route('/',protect).get(NotificationController.getAll);
router.route('/:id',protect).get(NotificationController.get);
router.route('/user/:id',protect).get(NotificationController.getByUserId);
router.route('/:id',protect).put(NotificationController.update);
router.route('/:id',protect).patch(NotificationController.patch);
router.route('/:id',protect).delete(NotificationController.remove);


export default router;