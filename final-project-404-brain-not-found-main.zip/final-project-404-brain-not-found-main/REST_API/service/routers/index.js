import userRouter from "./user-router.js"
import auctionRouter from "./auction-router.js";
import bidRouter from "./bid-routes.js"
import productRouter from "./product-router.js"


import notificationRouter from "./notification-router.js"

const initializeRoutes=(app) => {
    app.use('/users', userRouter);
    app.use('/notifications', notificationRouter);
    app.use('/auctions', auctionRouter);
    app.use('/bids', bidRouter);
    app.use('/products', productRouter);
    
}

export default initializeRoutes;